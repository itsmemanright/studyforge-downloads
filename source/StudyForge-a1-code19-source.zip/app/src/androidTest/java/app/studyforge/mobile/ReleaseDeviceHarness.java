package app.studyforge.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.WebView;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Runs only as a separately signed test APK on the development emulator. No AI requests. */
public final class ReleaseDeviceHarness extends Instrumentation {
    private Bundle arguments;
    @Override public void onCreate(Bundle arguments){this.arguments=arguments==null?new Bundle():arguments;super.onCreate(arguments);start();}
    private final java.util.ArrayList<String> checks=new java.util.ArrayList<>();
    private void check(boolean condition,String label){if(!condition)throw new AssertionError(label);checks.add(label);}
    private void main(Runnable task){AtomicReference<Throwable> error=new AtomicReference<>();runOnMainSync(()->{try{task.run();}catch(Throwable e){error.set(e);}});if(error.get()!=null)throw new RuntimeException(error.get());}
    private static Object field(Object target,String name){try{Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}catch(Exception e){throw new RuntimeException(e);}}
    private String read(WebView web,String script) throws Exception {CountDownLatch latch=new CountDownLatch(1);AtomicReference<String> value=new AtomicReference<>();main(()->web.evaluateJavascript(script,v->{value.set(v);latch.countDown();}));if(!latch.await(10,TimeUnit.SECONDS))throw new AssertionError("WebView read timeout");return value.get();}
    private Activity open(Class<? extends Activity> type){return startActivitySync(new Intent(getTargetContext(),type).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
    @Override public void onStart(){if("tutor-live".equals(arguments.getString("workflow"))){new ReleaseTutorHarness(this).run();return;}if("import-video".equals(arguments.getString("workflow"))){new ReleaseImportHarness(this).run();return;}if("network-video".equals(arguments.getString("workflow"))){new ReleaseWorkflowHarness(this).run();return;}Bundle result=new Bundle();Activity activity=null;try{
        MainActivity screen=(MainActivity)open(MainActivity.class);activity=screen;StudyApp app=(StudyApp)getTargetContext().getApplicationContext();
        check(!app.busy,"No existing user job is interrupted");long job=app.job;String original=app.workspace.toString();
        Method command=MainActivity.class.getDeclaredMethod("handle",String.class,org.json.JSONObject.class);command.setAccessible(true);
        for(String action:new String[]{"analyze","generate","continuePast","revise","proposeUi","proposeFeature","chatSend"}){
            main(()->{try{command.invoke(screen,action,new org.json.JSONObject());}catch(Exception e){throw new RuntimeException(e);}});
            AlertDialog dialog=(AlertDialog)field(screen,"aiConsentDialog");check(dialog!=null&&dialog.isShowing(),action+" shows native consent");
            main(()->{android.widget.TextView message=dialog.findViewById(android.R.id.message);if(message==null||!message.getText().toString().contains("OpenAI"))throw new AssertionError("Missing OpenAI disclosure");dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();});
            waitForIdleSync();
            check(app.job==job&&!app.busy&&original.equals(app.workspace.toString()),action+" cancel starts no job and keeps workspace");
        }
        ReportActivity report=(ReportActivity)open(ReportActivity.class);activity=report;WebView reportWeb=(WebView)field(report,"web");String body="";boolean ready=false;long until=SystemClock.uptimeMillis()+60000;
        while(SystemClock.uptimeMillis()<until){body=read(reportWeb,"JSON.stringify({title:document.title,text:document.body?document.body.innerText:'',fields:document.querySelectorAll('textarea').length,bridge:typeof window.StudyNative})");if(body.contains("Report details")&&body.contains("fields\\\":1")){ready=true;break;}Thread.sleep(500);}
        check(ready,"Public report form loads inside release WebView");
        check(body.contains("undefined"),"Report WebView has no StudyNative bridge");
        check(body.contains("계정이 응답에 포함되지")||body.contains("Sign in")||body.contains("로그인"),"Report form exposes account/privacy notice");
        android.graphics.Bitmap shot=getUiAutomation().takeScreenshot();if(shot!=null){try(java.io.FileOutputStream out=new java.io.FileOutputStream(new java.io.File(getTargetContext().getExternalFilesDir(null),"release18-report.png"))){shot.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}shot.recycle();}
        result.putBoolean("accountConnected",app.connection!=null&&app.connection.connected());result.putStringArrayList("checks",checks);result.putString("stream","PASS: "+checks.size()+" release-device checks. No AI inference, no report submission, no source or answer changes.\n");result.putString("result","passed");finish(Activity.RESULT_OK,result);
    }catch(Throwable error){result.putStringArrayList("checks",checks);result.putString("stream","FAIL: "+error.getClass().getSimpleName()+": "+error.getMessage()+"\n");result.putString("result","failed");finish(Activity.RESULT_CANCELED,result);}finally{if(activity!=null){Activity last=activity;main(last::finish);}}}
}
