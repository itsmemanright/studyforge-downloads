(function(root){'use strict';
 function rooms(w){const seen=new Set();return [w.dataset,...(w.rooms||[])].filter(d=>{if(!d?.id||seen.has(d.id))return false;seen.add(d.id);return true;});}
 function active(d){const r=d?.retry;return r?.sessions?.find(s=>s.id===r.activeId)||null;}
 function matches(q,v){return !!v&&q.stem===v.stem&&q.answer===v.answer&&JSON.stringify(q.options)===JSON.stringify(v.options);}
 function practice(d){const s=active(d);if(!d?.retry?.open||!s)return null;const questions=d.questions.filter(q=>s.ids.includes(q.id)&&matches(q,s.versions?.[q.id]));return {session:s,dataset:{...d,questions,answers:s.answers||{},uncertain:Object.fromEntries(Object.entries(s.answers||{}).map(([id,a])=>[id,!!a.uncertain])),completion:{},practice:true},excluded:s.ids.length-questions.length};}
 function wrongAttempts(d,q){let n=d.completion?.[q.id]?.priorWrong||0,a=d.answers?.[q.id];n+=a?.attempts?.length?a.attempts.filter(x=>Number.isInteger(x.selected)&&x.selected!==q.answer).length:a&&Number.isInteger(a.selected)&&a.selected!==q.answer?1:0;for(const s of d.retry?.sessions||[])if(s.answers?.[q.id]?.correct===false)n++;return n;}
 function shape(q){return {stem:q.stem,options:[...q.options],answer:q.answer};}
 // In-memory demo implementation only. Native Android validates and encrypts real records.
 function demoPractice(d,type,p){const next=JSON.parse(JSON.stringify(d)),r=next.retry||(next.retry={sessions:[],open:false});r.sessions||=[];
  if(type==='retryStart'){const ids=[...new Set(p.ids)].filter(id=>{const q=next.questions.find(q=>q.id===id);return q&&wrongAttempts(next,q)>=p.threshold;});if(!ids.length)throw Error('해당하는 오답이 없습니다.');const s={id:'demo-'+Date.now()+'-'+r.sessions.length,ids,versions:Object.fromEntries(ids.map(id=>[id,shape(next.questions.find(q=>q.id===id))])),answers:{},threshold:p.threshold};r.sessions.push(s);r.activeId=s.id;r.open=true;return next;}
  const s=active(next);if(!s)throw Error('이어갈 재풀이가 없습니다.');if(type==='retryPause'||type==='retryResume'){r.open=type==='retryResume';return next;}
  const q=next.questions.find(q=>q.id===p.id);if(!q||s.id!==p.sessionId||!matches(q,s.versions[p.id]))throw Error('문항이나 회차가 바뀌었습니다.');if(type==='retryAnswer'){if(s.answers[p.id])throw Error('이미 채점한 문항입니다.');s.answers[p.id]={selected:p.selected,correct:p.selected===q.answer};}else if(type==='retryUncertain'&&s.answers[p.id])s.answers[p.id].uncertain=!!p.value;return next;
 }
 const api={rooms,active,practice,matches,wrongAttempts,demoPractice};root.StudyTools=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window==='undefined'?globalThis:window);
