package app.studyforge.mobile;

import org.json.*;
import java.util.*;

/** Independent practice rounds. Never changes the original answers or completion. */
final class RetryPractice {
    static JSONObject shape(JSONObject q)throws Exception{return Json.object("stem",q.getString("stem"),"options",Json.arrayCopy(q.getJSONArray("options")),"answer",q.getInt("answer"));}
    static boolean matches(JSONObject q,JSONObject version){if(q==null||version==null)return false;return q.optString("stem").equals(version.optString("stem"))&&q.optInt("answer",-1)==version.optInt("answer",-2)&&q.optJSONArray("options")!=null&&version.optJSONArray("options")!=null&&q.optJSONArray("options").toString().equals(version.optJSONArray("options").toString());}
    static int retryWrong(JSONObject d,String id){int count=0;JSONObject retry=d.optJSONObject("retry");JSONArray rounds=retry==null?null:retry.optJSONArray("sessions");if(rounds!=null)for(int i=0;i<rounds.length();i++){JSONObject round=rounds.optJSONObject(i),answers=round==null?null:round.optJSONObject("answers"),a=answers==null?null:answers.optJSONObject(id);if(a!=null&&Boolean.FALSE.equals(a.opt("correct")))count++;}return count;}
    static int wrong(JSONObject d,JSONObject q){String id=q.optString("id");int count=retryWrong(d,id);JSONObject all=d.optJSONObject("answers"),a=all==null?null:all.optJSONObject(id),complete=d.optJSONObject("completion"),c=complete==null?null:complete.optJSONObject(id);if(c!=null)count+=c.optInt("priorWrong");if(a!=null){JSONArray attempts=a.optJSONArray("attempts");if(attempts!=null&&attempts.length()>0){for(int i=0;i<attempts.length();i++)if(attempts.optJSONObject(i)!=null&&attempts.optJSONObject(i).optInt("selected",-1)>=0&&attempts.optJSONObject(i).optInt("selected")!=q.optInt("answer"))count++;}else if(a.optInt("selected",-1)>=0&&a.optInt("selected")!=q.optInt("answer"))count++;}return count;}
    static JSONObject apply(JSONObject original,String action,JSONObject request)throws Exception{
        JSONObject d=Json.copy(original);JSONObject retry=d.optJSONObject("retry");if(retry==null){retry=Json.object("sessions",new JSONArray(),"open",false);d.put("retry",retry);}if(retry.optJSONArray("sessions")==null)retry.put("sessions",new JSONArray());JSONArray sessions=retry.getJSONArray("sessions");
        Map<String,JSONObject> questions=new LinkedHashMap<>();JSONArray rows=d.getJSONArray("questions");for(int i=0;i<rows.length();i++){JSONObject q=rows.getJSONObject(i);questions.put(q.getString("id"),q);}
        if(action.equals("retryStart")){
            int threshold=request.optInt("threshold",1);if(threshold<1||threshold>1_000_000)throw new Exception("누적 오답 기준은 1 이상의 정수여야 합니다.");
            JSONArray wanted=request.getJSONArray("ids"),ids=new JSONArray();JSONObject versions=new JSONObject();Set<String> seen=new HashSet<>();
            for(int i=0;i<wanted.length();i++){String id=wanted.getString(i);JSONObject q=questions.get(id);if(q!=null&&seen.add(id)&&wrong(d,q)>=threshold){ids.put(id);versions.put(id,shape(q));}}
            if(ids.length()==0)throw new Exception("선택한 출처·범위에 해당하는 오답이 없습니다. 기존 기록은 유지했습니다.");
            String id=UUID.randomUUID().toString();sessions.put(Json.object("id",id,"ids",ids,"versions",versions,"answers",new JSONObject(),"threshold",threshold,"createdAt",System.currentTimeMillis()));retry.put("activeId",id).put("open",true);return d;
        }
        JSONObject round=null;for(int i=0;i<sessions.length();i++)if(sessions.getJSONObject(i).optString("id").equals(retry.optString("activeId")))round=sessions.getJSONObject(i);
        if(round==null)throw new Exception("이어갈 재풀이 회차가 없습니다.");
        if(action.equals("retryPause")||action.equals("retryResume")){retry.put("open",action.equals("retryResume"));return d;}
        if(!retry.optBoolean("open")||!round.getString("id").equals(request.optString("sessionId")))throw new Exception("재풀이 회차가 바뀌었습니다. 다시 확인해 주세요.");
        String id=request.getString("id");JSONObject q=questions.get(id);if(!matches(q,round.getJSONObject("versions").optJSONObject(id)))throw new Exception("문항이 개정되었습니다. 이전 재풀이 기록은 보존합니다.");
        JSONObject answers=round.getJSONObject("answers");
        if(action.equals("retryAnswer")){int choice=request.getInt("selected");if(choice<0||choice>=q.getJSONArray("options").length())throw new Exception("보기 번호가 잘못되었습니다.");if(answers.has(id))throw new Exception("이미 채점한 문항입니다. 새 회차에서 다시 풀 수 있습니다.");answers.put(id,Json.object("selected",choice,"correct",choice==q.getInt("answer"),"at",System.currentTimeMillis()));}
        else if(action.equals("retryUncertain")){JSONObject a=answers.optJSONObject(id);if(a==null)throw new Exception("재풀이 답안을 제출한 뒤 표시하세요.");a.put("uncertain",request.getBoolean("value"));}
        else throw new Exception("지원하지 않는 재풀이 요청입니다.");return d;
    }
}
