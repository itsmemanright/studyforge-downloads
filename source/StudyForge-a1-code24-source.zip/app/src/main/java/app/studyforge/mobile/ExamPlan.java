package app.studyforge.mobile;
import org.json.*;
import java.util.*;

final class ExamPlan {
    static JSONArray validate(JSONArray plan,JSONObject workspace)throws Exception{
        if(plan.length()>32)throw new Exception("시험 일정은 32개까지 보관할 수 있습니다.");Set<String> rooms=new HashSet<>();JSONObject current=workspace.optJSONObject("dataset");if(current!=null)rooms.add(current.getString("id"));JSONArray saved=workspace.optJSONArray("rooms");if(saved!=null)for(int i=0;i<saved.length();i++)rooms.add(saved.getJSONObject(i).getString("id"));
        JSONArray out=new JSONArray();Set<String> ids=new HashSet<>();for(int i=0;i<plan.length();i++){JSONObject row=plan.getJSONObject(i);String id=row.getString("id"),title=row.getString("title").trim();Object rawDay=row.get("day");if(!(rawDay instanceof Number)||((Number)rawDay).doubleValue()!=((Number)rawDay).intValue())throw new Exception("시험 요일이 올바르지 않습니다.");int day=row.getInt("day");if(!id.matches("[A-Za-z0-9-]{1,80}")||!ids.add(id)||title.isEmpty()||title.length()>100||day<0||day>6)throw new Exception("시험 이름·요일을 확인하세요.");JSONArray selected=row.getJSONArray("rooms"),valid=new JSONArray();Set<String> used=new HashSet<>();if(selected.length()>100)throw new Exception("선택한 학습실이 너무 많습니다.");for(int j=0;j<selected.length();j++){String room=selected.getString(j);if(!rooms.contains(room))throw new Exception("학습실이 바뀌었습니다. 시험 일정을 다시 확인하세요.");if(used.add(room))valid.put(room);}out.put(Json.object("id",id,"title",title,"day",day,"rooms",valid));}return out;
    }
}
