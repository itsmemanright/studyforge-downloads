package app.studyforge.mobile;
import org.json.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class ExamPlanTest {
    static JSONObject workspace()throws Exception{return Json.object("dataset",Json.object("id","one"),"rooms",Json.array(Json.object("id","two")));}
    static JSONObject row(Object day,JSONArray rooms)throws Exception{return Json.object("id","exam-1","title","전공 시험","day",day,"rooms",rooms);}
    @Test public void scheduleAcceptsEveryWeekdayAndOnlyExistingRoomIds()throws Exception{for(int i=0;i<7;i++){JSONArray plan=ExamPlan.validate(Json.array(row(i,Json.array("one","two","two"))),workspace());assertEquals(i,plan.getJSONObject(0).getInt("day"));assertEquals(2,plan.getJSONObject(0).getJSONArray("rooms").length());}assertEquals(0,ExamPlan.validate(new JSONArray(),workspace()).length());}
    @Test public void invalidOrForeignScheduleDoesNotChangeWorkspace()throws Exception{JSONObject w=workspace();String before=w.toString();for(Object day:new Object[]{-1,7,1.5,"3"}){try{ExamPlan.validate(Json.array(row(day,Json.array("one"))),w);fail();}catch(Exception expected){}}try{ExamPlan.validate(Json.array(row(3,Json.array("foreign"))),w);fail();}catch(Exception expected){}assertEquals(before,w.toString());}
}
