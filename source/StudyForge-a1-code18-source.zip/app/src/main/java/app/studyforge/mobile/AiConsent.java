package app.studyforge.mobile;

import java.util.Map;

/** Every action that sends learning content to AI requires a native, per-request choice. */
final class AiConsent {
    private static final Map<String,String> ACTIONS=Map.of(
        "analyze","자료 전체 분석", "generate","문제 생성·검수",
        "continuePast","족보 추가 출제", "revise","문항 수정",
        "proposeUi","화면 변경안 생성", "proposeFeature","개인 기능 생성·검수");
    static boolean required(String action){return ACTIONS.containsKey(action);}
    static String disclosure(String action){
        if(!required(action))throw new IllegalArgumentException("AI 전송 작업이 아닙니다.");
        String content=switch(action){
            case "analyze" -> "선택한 학습 자료의 텍스트·PDF/사진의 페이지 이미지·파일명, 시험 범위와 교수 지시";
            case "generate","continuePast" -> "자료에서 준비한 발췌·개념·출처, 시험 범위·출제 설정과 기존 문항의 필요한 부분";
            case "revise" -> "수정할 문항·보기·해설과 관련 원문 근거, 수정 요청";
            case "proposeUi" -> "현재 화면 구성과 입력한 변경 요청";
            default -> "입력한 기능 요청과 기존 기능 코드, 관련 설정·학습실 정보";
        };
        return "작업: "+ACTIONS.get(action)+"\n\n"+content+"가 OpenAI로 전송되어 처리됩니다. 결과는 이 기기에 저장합니다. 본인의 ChatGPT 구독 사용량을 사용하며 OpenAI의 보관·처리 정책이 적용됩니다.\n\n전송하면 안 되는 개인정보가 있다면 취소하고 자료·요청에서 먼저 제거하세요. 동의하지 않아도 체험과 이미 만든 문제 풀이는 계속 사용할 수 있습니다.";
    }
}
