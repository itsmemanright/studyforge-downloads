package app.studyforge.mobile;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.*;
import android.widget.*;
import java.io.ByteArrayInputStream;

/** A public reporting form stays inside the app, without the learning workspace bridge. */
public final class ReportActivity extends Activity {
    private WebView web;private TextView status;
    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);ScreenInsets.apply(root,0);
        LinearLayout bar=new LinearLayout(this);Button close=new Button(this);close.setText("닫기");close.setOnClickListener(v->finish());bar.addView(close);
        TextView title=new TextView(this);title.setText("AI 콘텐츠·문항 신고");bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button retry=new Button(this);retry.setText("다시 열기");retry.setOnClickListener(v->web.loadUrl(ReportLinks.FORM));bar.addView(retry);root.addView(bar);
        status=new TextView(this);status.setPadding(16,12,16,12);int n=getIntent().getIntExtra("number",0);
        status.setText((n>0?n+"번 문항 신고 · ":"")+"Google 로그인 없이 제출할 수 있어요. 신고 내용은 Google Forms를 통해 개발자에게 전달합니다. 문항·해설은 필요한 부분만 적어주세요. 원본 자료·계정·토큰은 자동 첨부하지 않습니다.");root.addView(status);
        web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){boolean block=!ReportLinks.navigation(r.getUrl().toString());if(block&&r.isForMainFrame())status.setText("이 화면에서는 신고 양식만 열 수 있습니다. 닫기를 누르면 학습 화면으로 돌아갑니다.");return block;}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return ReportLinks.resource(r.getUrl().toString())?null:new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())status.setText("신고 양식을 불러오지 못했어요. 인터넷 연결을 확인하고 ‘다시 열기’를 누르세요. 신고는 아직 제출되지 않았습니다.");}
            @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail d){finish();return true;}
        });web.loadUrl(ReportLinks.FORM);
    }
    @Override protected void onDestroy(){if(web!=null){((android.view.ViewGroup)web.getParent()).removeView(web);web.destroy();web=null;}super.onDestroy();}
}
