package app.studyforge.mobile;

import java.net.URI;
import java.util.Set;

final class ReportLinks {
    static final String FORM="https://docs.google.com/forms/d/e/1FAIpQLSeDO2x6QNZD9m-aylOqlJXmo4ij2TIw_0BvDSprcnVgquVxMQ/viewform";
    private static final String FORM_PATH="/forms/d/e/1FAIpQLSeDO2x6QNZD9m-aylOqlJXmo4ij2TIw_0BvDSprcnVgquVxMQ/";
    private static final Set<String> HOSTS=Set.of("docs.google.com","www.google.com","www.gstatic.com","ssl.gstatic.com","fonts.googleapis.com","fonts.gstatic.com","lh3.googleusercontent.com");
    static boolean resource(String url){try{URI u=URI.create(url);return "https".equals(u.getScheme())&&u.getRawUserInfo()==null&&(u.getPort()==-1||u.getPort()==443)&&HOSTS.contains(u.getHost());}catch(Exception e){return false;}}
    static boolean navigation(String url){try{URI u=URI.create(url);String p=u.getPath();if(p!=null)p=p.replaceFirst("^/forms/u/[0-9]+/","/forms/");return resource(url)&&"docs.google.com".equals(u.getHost())&&(p.equals(FORM_PATH+"viewform")||p.equals(FORM_PATH+"formResponse"));}catch(Exception e){return false;}}
}
