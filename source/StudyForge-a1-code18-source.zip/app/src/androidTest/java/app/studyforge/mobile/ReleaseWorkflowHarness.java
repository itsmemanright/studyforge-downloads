package app.studyforge.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.WebView;
import android.accessibilityservice.AccessibilityService;
import org.json.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Optional, explicitly run integration recording. Uses only the authored sample below. */
public final class ReleaseWorkflowHarness {
    private final Instrumentation harness;
    ReleaseWorkflowHarness(Instrumentation harness){this.harness=harness;}
    private android.content.Context getTargetContext(){return harness.getTargetContext();}
    private void runOnMainSync(Runnable r){harness.runOnMainSync(r);}
    private Activity startActivitySync(Intent i){return harness.startActivitySync(i);}
    private void waitForIdleSync(){harness.waitForIdleSync();}
    private UiAutomation getUiAutomation(){return harness.getUiAutomation();}
    private void finish(int code,Bundle result){harness.finish(code,result);}
    private StudyApp app;private MainActivity screen;private WebView web;private String originalOwner;private JSONObject originalWorkspace;private ParcelFileDescriptor recording;
    private static final String SAMPLE="광합성은 빛 에너지를 화학 에너지로 바꾸는 과정이다. 엽록체의 틸라코이드 막에서는 명반응이 일어나며 ATP와 NADPH가 만들어진다. 물이 분해되면 산소가 방출된다. 스트로마의 캘빈 회로에서는 이산화탄소가 고정되고 ATP와 NADPH가 사용된다. 기공이 닫히면 이산화탄소 유입이 감소할 수 있다. 빛 보상점에서는 광합성과 호흡의 이산화탄소 교환이 같다. 빛이 증가해도 광포화점 이후에는 다른 제한 요인이 영향을 준다. 이 문서는 스터디포지 개발자가 출시 검수용으로 직접 작성한 일반 과학 필기이며 실제 교재·기출·개인 자료가 아니다.";
    
    private void main(Runnable task){AtomicReference<Throwable> error=new AtomicReference<>();runOnMainSync(()->{try{task.run();}catch(Throwable e){error.set(e);}});if(error.get()!=null)throw new RuntimeException(error.get());}
    private static Object field(Object o,String name){try{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}catch(Exception e){throw new RuntimeException(e);}}
    private String js(String script) throws Exception {CountDownLatch latch=new CountDownLatch(1);AtomicReference<String> result=new AtomicReference<>();main(()->web.evaluateJavascript(script,v->{result.set(v);latch.countDown();}));if(!latch.await(10,TimeUnit.SECONDS))throw new AssertionError("WebView timeout");return result.get();}
    public void run(){Bundle result=new Bundle();long began=0;boolean isolated=false;try{
        screen=(MainActivity)startActivitySync(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));app=(StudyApp)getTargetContext().getApplicationContext();web=(WebView)field(screen,"web");
        if(app.busy)throw new AssertionError("기존 작업이 진행 중입니다. 기존 작업은 변경하지 않았습니다.");
        long modelsUntil=SystemClock.uptimeMillis()+40000;while(app.modelsLoading&&SystemClock.uptimeMillis()<modelsUntil)Thread.sleep(200);
        if(app.connection==null||!app.connection.connected())throw new AssertionError("실제 AI 작업 녹화에는 이 검수 기기의 기존 ChatGPT 연결이 필요합니다. 로그인 정보를 생성하거나 우회하지 않았습니다.");
        getUiAutomation().grantRuntimePermission(getTargetContext().getPackageName(),android.Manifest.permission.POST_NOTIFICATIONS);
        if(app.models.length()==0){app.reloadModels();long until=SystemClock.uptimeMillis()+40000;while(app.modelsLoading&&SystemClock.uptimeMillis()<until)Thread.sleep(200);if(app.models.length()==0)throw new AssertionError("사용 가능한 모델이 없습니다.");}
        synchronized(app){originalOwner=app.profile;originalWorkspace=app.workspace;app.save();app.profile="release_qa_"+java.util.UUID.randomUUID();app.workspace=app.load(app.profile);isolated=true;app.workspace.put("model",originalWorkspace.optString("model",app.models.getJSONObject(0).getString("slug")));app.state();}
        long until=SystemClock.uptimeMillis()+20000;while(SystemClock.uptimeMillis()<until){if("\"function\"".equals(js("typeof window.studyNativeReceive")))break;Thread.sleep(100);}Thread.sleep(1000);
        js("document.querySelector('#source-title').value='출시 검수용 과학 필기';document.querySelector('#source-text').value="+JSONObject.quote(SAMPLE)+";document.querySelector('#add-text').click();");
        until=SystemClock.uptimeMillis()+10000;while(app.workspace.getJSONArray("sources").length()==0&&SystemClock.uptimeMillis()<until)Thread.sleep(100);if(app.workspace.getJSONArray("sources").length()!=1)throw new AssertionError("검수용 자료 추가 실패");
        js("document.querySelector('#subject').value='출시 검수용 과학';document.querySelector('#scope').value='광합성의 명반응과 캘빈 회로';document.querySelector('#analyze').scrollIntoView({block:'center'});");Thread.sleep(500);
        recording=getUiAutomation().executeShellCommand("screenrecord --time-limit 24 --bit-rate 2000000 /sdcard/Download/StudyForge-foreground-service-demo.mp4");began=SystemClock.uptimeMillis();Thread.sleep(1000);
        js("document.querySelector('#analyze').click();");waitForIdleSync();AlertDialog dialog=(AlertDialog)field(screen,"aiConsentDialog");if(dialog==null)throw new AssertionError("전송 동의 화면이 없습니다.");Thread.sleep(1500);main(()->dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick());
        until=SystemClock.uptimeMillis()+3000;while(!app.busy&&SystemClock.uptimeMillis()<until)Thread.sleep(100);if(!app.busy)throw new AssertionError("사용자 동작 뒤 분석 작업이 시작되지 않았습니다.");Thread.sleep(1500);
        getUiAutomation().performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);Thread.sleep(1800);harness.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);Thread.sleep(800);
        if(app.busy)js("document.querySelector('#analysis-stop').click();");Thread.sleep(1000);
        while(SystemClock.uptimeMillis()-began<26000)Thread.sleep(200);
        result.putString("stream","PASS: actual owned-sample analysis started by the UI, native OpenAI consent shown, foreground notification recorded, cancel/completion shown. User workspace isolated and restored. Video: /sdcard/Download/StudyForge-foreground-service-demo.mp4\n");result.putString("result","passed");
    }catch(Throwable e){result.putString("stream","FAIL: "+e.getClass().getSimpleName()+": "+e.getMessage()+"\n");result.putString("result","failed");}
    finally{if(began>0)try{while(SystemClock.uptimeMillis()-began<26000)Thread.sleep(200);}catch(InterruptedException ignored){}if(recording!=null)try{recording.close();}catch(Exception ignored){}if(isolated&&app!=null)synchronized(app){app.cancel();app.profile=originalOwner;app.workspace=originalWorkspace;app.state();}if(screen!=null)main(screen::finish);}
        finish(result.getString("result").equals("passed")?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
    }
}
