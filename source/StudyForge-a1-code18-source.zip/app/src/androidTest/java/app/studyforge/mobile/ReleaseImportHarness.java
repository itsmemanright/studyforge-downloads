package app.studyforge.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.MediaStore;
import android.net.Uri;
import android.view.accessibility.AccessibilityNodeInfo;
import android.webkit.WebView;
import org.json.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Optional actual import recording. An ActivityMonitor supplies an owned file-picker result. */
final class ReleaseImportHarness {
    private final Instrumentation test;
    private static final String NAME="StudyForge-review-source.txt";
    ReleaseImportHarness(Instrumentation test){this.test=test;}
    private void main(Runnable r){test.runOnMainSync(r);}
    private Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
    private void js(WebView w,String s)throws Exception{CountDownLatch latch=new CountDownLatch(1);main(()->w.evaluateJavascript(s,v->latch.countDown()));if(!latch.await(10,TimeUnit.SECONDS))throw new AssertionError("WebView timeout");}
    private boolean clickText(String text){AccessibilityNodeInfo root=test.getUiAutomation().getRootInActiveWindow();if(root==null)return false;for(AccessibilityNodeInfo n:root.findAccessibilityNodeInfosByText(text)){android.graphics.Rect bounds=new android.graphics.Rect();n.getBoundsInScreen(bounds);if(bounds.isEmpty())continue;long at=SystemClock.uptimeMillis();test.sendPointerSync(android.view.MotionEvent.obtain(at,at,android.view.MotionEvent.ACTION_DOWN,bounds.centerX(),bounds.centerY(),0));test.sendPointerSync(android.view.MotionEvent.obtain(at,at+60,android.view.MotionEvent.ACTION_UP,bounds.centerX(),bounds.centerY(),0));return true;}return false;}
    void run(){Bundle result=new Bundle();StudyApp app=null;MainActivity screen=null;JSONObject original=null;String owner=null;Uri sample=null;ParcelFileDescriptor recording=null;long began=0;try{
        android.util.Log.i("StudyForgeQA","start-activity");Context context=test.getTargetContext();screen=(MainActivity)test.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));android.util.Log.i("StudyForgeQA","activity-started");app=(StudyApp)context.getApplicationContext();if(app.busy)throw new AssertionError("Existing work was not interrupted");WebView web=(WebView)field(screen,"web");
        synchronized(app){owner=app.profile;original=app.workspace;app.save();app.profile="release_import_"+java.util.UUID.randomUUID();app.workspace=app.load(app.profile);app.state();}
        android.util.Log.i("StudyForgeQA","workspace-isolated");ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,NAME);v.put(MediaStore.Downloads.MIME_TYPE,"text/plain");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);v.put(MediaStore.Downloads.IS_PENDING,1);sample=context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(sample==null)throw new AssertionError("Sample file creation failed");
        byte[] block=("This is developer-authored release QA data. Photosynthesis converts light energy into chemical energy. It is not a textbook, exam, personal note, or user document.\n").repeat(512).getBytes(java.nio.charset.StandardCharsets.UTF_8);try(java.io.OutputStream out=context.getContentResolver().openOutputStream(sample)){for(int i=0;i<128;i++)out.write(block);}v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);context.getContentResolver().update(sample,v,null,null);
        android.util.Log.i("StudyForgeQA","sample-ready");test.getUiAutomation().grantRuntimePermission(context.getPackageName(),android.Manifest.permission.POST_NOTIFICATIONS);Thread.sleep(1000);js(web,"document.querySelector('#pick-file').scrollIntoView({block:'center'});");
        android.util.Log.i("StudyForgeQA","webview-ready");Intent picked=new Intent().setData(sample).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);IntentFilter pickerFilter=new IntentFilter(Intent.ACTION_OPEN_DOCUMENT);pickerFilter.addCategory(Intent.CATEGORY_OPENABLE);pickerFilter.addDataType("*/*");Instrumentation.ActivityMonitor monitor=test.addMonitor(pickerFilter,new Instrumentation.ActivityResult(Activity.RESULT_OK,picked),true);
        recording=test.getUiAutomation().executeShellCommand("screenrecord --time-limit 24 --bit-rate 2000000 /sdcard/Download/StudyForge-file-import-demo.mp4");began=SystemClock.uptimeMillis();Thread.sleep(1000);js(web,"document.querySelector('#pick-file').click();");
        android.util.Log.i("StudyForgeQA","import-clicked");long until=SystemClock.uptimeMillis()+8000;while(!app.busy&&app.workspace.getJSONArray("sources").length()==0&&SystemClock.uptimeMillis()<until)Thread.sleep(100);if(!app.busy&&app.workspace.getJSONArray("sources").length()==0)throw new AssertionError("The file picker result did not start import");test.removeMonitor(monitor);
        if(app.busy){test.getUiAutomation().performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);Thread.sleep(1000);test.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);}
        until=SystemClock.uptimeMillis()+60000;while(app.busy&&SystemClock.uptimeMillis()<until)Thread.sleep(200);if(app.busy||app.workspace.getJSONArray("sources").length()!=1)throw new AssertionError("Selected source did not finish importing");
        js(web,"document.querySelector('#sources').scrollIntoView({block:'center'});");while(SystemClock.uptimeMillis()-began<26000)Thread.sleep(200);
        result.putString("result","passed");result.putString("stream","PASS: developer-authored TXT supplied as the Android picker result by a test ActivityMonitor; actual UI import action, encryption, parsing, completion and source listing executed. No AI request. Original workspace restored. Video: /sdcard/Download/StudyForge-file-import-demo.mp4\n");
    }catch(Throwable e){result.putString("result","failed");result.putString("stream","FAIL: "+e.getClass().getSimpleName()+": "+e.getMessage()+"\n");}
    finally{if(began>0)try{while(SystemClock.uptimeMillis()-began<26000)Thread.sleep(200);}catch(InterruptedException ignored){}if(recording!=null)try{recording.close();}catch(Exception ignored){}if(sample!=null)try{test.getTargetContext().getContentResolver().delete(sample,null,null);}catch(Exception ignored){}if(app!=null&&original!=null)synchronized(app){app.cancel();app.profile=owner;app.workspace=original;app.state();}if(screen!=null){MainActivity last=screen;main(last::finish);}}
        test.finish("passed".equals(result.getString("result"))?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
    }
}
