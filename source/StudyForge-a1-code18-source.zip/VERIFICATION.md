# StudyForge a1 확인 기록 · 2026-10-17

- Gradle testDebugUnitTest / lintDebug / assembleDebug 성공. Java 검사 45개 성공, 실패·오류 0. Node 검사 29개 성공. 총 74개.
- 전체 파일: 503쪽의 핵심 구간에 빠짐·중복이 없음을 확인. 500쪽 전체를 모의 모델에 전달하고 모든 분석 기록이 통합 단계에 들어가는지 확인. 긴 TXT 분할, 후반 페이지 인용, 읽지 못한 페이지 거부, 중단·실패 후 이어서 처리, 파일·모델 변경 시 캐시 분리 검사.
- 원본 파일: 블록 암호화 왕복, 변조·잘림·다른 파일 ID·크기 초과·취소 거부. 512MB 파일을 메모리에 한꺼번에 읽는 방식은 사용하지 않음. 512MB 실제 교재 실기기 처리는 미검증.
- 연결: 공식 모델 목록 형식, 숨김 모델 제외, ID/이름 표시, 2MB 넘는 메타데이터, 빈 목록·오류·재시도 UI 검사. OAuth 콜백의 헤더 배출·크기 제한 검사. PKCE·상태값·JWT·SSE·인용 검증 기존 검사 유지.
- 맞춤 화면: 허용된 설정만 적용. 코드/알 수 없는 속성·필수 화면 숨김·중복 순서·범위 초과 거부. 미리보기·취소는 저장 요청을 하지 않고, 적용·되돌리기를 명시적으로 요청함. 계정 변경 시 미적용 변경안 분리. 통상 기록 갱신 때 문제 컨테이너를 이동하지 않음.
- 족보: 원문·추론·재구성·확장 구분, 정확한 단서 인용, 활용·미활용 목록, 중복 거부, 정답표 없는 재구성, 낮은 확실도 표시 기존 검사 유지.
- 브라우저 검수: APK와 동일한 화면 자산에서 전체 파일 추가, 모델 상태, 맞춤 화면 순서/표시 제어를 확인. 화면 체험은 고정 자료이며 실제 AI 성공 결과가 아님.
- 사용자 제공 휴대폰 화면에서 기존 버전의 ChatGPT 로그인과 구독 사용 권한 연결 성공은 확인됨. 새 버전의 휴대폰 OAuth 복귀·모델 목록·실제 전체 교재 분석·문제 생성·자연어 화면 변경은 실기기 미확인. 이 PC에는 연결된 Android 기기가 없음.
- APK는 Android 8 이상 개발용 서명 시제품. 기존 0.1.2와 앱 ID·서명 일치 및 새 버전 코드 확인. 기존 앱 위에 업데이트 설치하고 삭제하지 말 것.
- 예전에 1–5쪽 등 일부만 추가한 파일은 원본 PDF 전체를 다시 추가해야 함. 이전 풀이 기록은 유지.

간호 문제은행 사이트 계정 동기화와 앱 자료 보관은 별개입니다. 앱의 자료·설정·분석·풀이 기록은 기기에 암호화해 보관하며 JSON 백업에는 새 원본 파일 자체가 포함되지 않습니다. 새 공부 기능의 코드는 격리된 실행 화면에서 작동하며, 기본 APK의 임의 수정·새 Android 권한·외부 서비스 연결은 포함하지 않습니다.

## a1 새 기능 검수
- 실제 새 프로그램 생성·재검수와 구조 오류 수정, 프로그램/권한/기본 동작 변경 검증, 버전 추가·되돌리기, 나중의 수동 설정 변경 보존, 기존 문제/풀이/기능 데이터 보존을 검사했습니다.
- 생성 프로그램은 기본 앱의 JavaScript 인터페이스가 없는 별도 WebView의 opaque iframe에서 실행합니다. 파일·네트워크 접근을 차단하며, 요청은 허용된 기능별 API로만 전달합니다. 로그인 토큰과 원본 파일은 전달하지 않습니다.
- 원본 학습실 읽기와 기능별 상태 저장, 선택한 문항의 본 앱 재풀이 연결, 사용자 확인 후 선택 모델 요청을 구현했습니다. 미리보기에서는 실제 보관·재풀이·AI 요청을 수행하지 않습니다.
- 실제 예제 JavaScript를 실행해 일정 계산·메모 보관 요청/응답·실패 처리·구문 오류의 검사 통과 방지를 확인했습니다.
- Chromium 브라우저의 실제 sandbox에서 로컬 복습 큐와 6개 실행 검사(우선순위·일정 계산·화면 요소·부모 문서 접근 차단·일반 Android 브리지 없음·네트워크 차단)가 통과했습니다. 직접 3일 뒤 복습 버튼을 눌러 날짜 갱신을 확인했습니다. 고정 예제이며 실제 AI 생성 결과가 아닙니다.
- 앱 자체 자동 검사 총 74개 통과(Java 45 + Node 29). Gradle 검사·Lint·APK 빌드 성공. Lint 오류 0; 기존/의도된 경고는 별도 리포트에 남아 있습니다.
- 사용자의 실제 구독으로 새 기능 생성 → Android 미리보기 → 적용 → 앱 재실행 후 보관의 전체 과정은 미검증입니다. Android 메시지 채널·렌더러 복구·네이티브 확인창도 실제 폰에서 추가 검증해야 합니다. 소프트웨어 생성의 모든 요구사항 충족을 주장하지 않습니다.

## Google Play 업로드 파일 · 2026-10-17
위 개발용 APK 검증과 별도로 `StudyForge-a1-play.aab`를 생성했습니다. 버전 a1 / 코드 6 / target 36 / min 26, release 빌드, 새 비디버그 업로드 키 서명입니다. 컴파일·Release 단위 검사 45개·Release Lint·bundleRelease·bundletool validate·JAR 서명 무결성·자산 일치 검증을 통과했습니다. Google Play Console 업로드 승인은 아직 확인하지 않았습니다.

Android 16 대상 전환에 맞춰 클로바노트 가져오기 화면의 시스템 뒤로가기 콜백과 화면 여백 처리를 조정했습니다. 실제 Android 16 휴대폰 동작은 추가 확인이 필요합니다. 서명이 바뀌는 Play 설치판으로 이동하기 전에 기존 개발용 앱의 데이터 이관을 확인해야 합니다.

## Play Console 패키지 이름 반영
Play Console이 요구한 패키지 이름 com.studyforge.app을 applicationId로 적용했습니다. 표시 버전은 a1, 내부 버전 코드는 7입니다. Java namespace는 기존 구현 클래스와 일치하도록 유지하고, 번들 manifest의 실제 application/activity/service 클래스 이름을 대조합니다. 로그인 뒤 앱 복귀 링크와 manifest의 scheme도 새 applicationId로 맞춰 이전 시제품과 충돌하지 않도록 했습니다.

이 Play 앱은 기존 app.studyforge.mobile 개발용 시제품과 별개로 설치되며 기존 기록을 자동 공유하지 않습니다. 기존 휴대폰 앱은 보존해야 합니다.


## Play version code 8

Play Console reported version code 7 already used. The next bundle keeps versionName a1 and applicationId com.studyforge.app, increments versionCode to 8, and reuses the existing upload signing key. This supersedes the previous code 7 upload artifact.


## a1 / code 9

Removed the STEP 01 past-exam demo button, its event handler and unused styling. Past-exam inference fixtures now live only under tests. Real past-exam material import and generation are unchanged. Release script now builds both AAB and APK from the same sources and signing configuration.


## a1 / code 9: automatic shared transcript and PDF request batching

Clova link entry is inline. The native reader only imports complete script.blockList from the official note detail response, rejects login/menu HTML, missing blocks and oversize text without truncation, and binds source addition to the original app profile. No app bridge or ChatGPT token is exposed to the remote note page. Restricted notes return a clear TXT/paste fallback. The provided share link opened in the existing signed-in desktop browser; anonymous access and automatic Android import on a physical phone remain unverified. Reference: https://help.naver.com/service/24269/contents/13084?lang=ko&osType=COMMONOS

Adjacent missing PDF checkpoints now share an eight-core-page request, with at most ten image pages including boundary context. Legacy four-page cache keys remain valid; tests verify cache reuse, every page covered, cancellation and missing-page handling. 500-page simulated extraction count is reduced from 125 to 63 requests, with no claim of measured real-model speedup. Reference: https://developers.openai.com/api/docs/guides/latency-optimization


## a1 / code 10

- Bounded concurrent extraction with deterministic source-order assembly. Tests cover all 500 pages and compare complete prepared evidence with sequential extraction; model and extraction instructions are unchanged. Existing four-page checkpoints remain compatible.
- On a transient rate limit, reduce concurrency to one and retry only the rejected unit once. Retain other completed concurrent chunks when one fails. Cancellation guards prevent in-flight results being committed and disconnect all tracked Responses connections.
- Source rendering remains serialized for safe PDF access and bounded bitmap allocation. Avoid serializing/copying the same base64 image strings merely to validate four-page subranges. Device heap caps concurrency at 1/2/3.
- Immediate import state is emitted before file-provider name/type/size queries on the worker thread. Byte progress follows authenticated encrypted block I/O; unknown sizes use indeterminate progress. Finished/error/canceled states close the modal, success displays a toast.
- Analysis card contains its own Stop button and paused Resume/Cancel previous controls. Cancel previous clears only the active analysis pointer, preserving source files, datasets, answers and completed caches.
- Mobile-width UI verified with test-only fixtures; physical Android import, live-model speed and actual content quality remain unmeasured. UI fixtures are excluded from APK assets.


## a1 / code 11

Analysis-card spinner and traveling bar remain active while busy reading/combining/generating/reviewing. Paused/completed jobs hide the activity indicator; determinate page progress still uses only completed checkpoints. Existing lifecycle UI test also checks activity visibility and aria-busy. No extraction/model/quality parameters changed.


## a1 / code 12

Analysis and question generation are explicit separate native commands. Analysis stores a fingerprinted, account-scoped prepared artifact and stops without calling StudyGenerator. Generation requires that artifact and validates the source/config fingerprint; question count/mode may change without rereading. Restart preserves a ready receipt. Resume only runs analysis.

Tests cover serialized prepared-artifact reuse, changed sources/scope rejection, missing/empty artifact rejection, explicit analyze then generate UI commands, no auto-generation, 999/1000=99% (no premature 100%), phase-specific activity indicators, and stale-scope button disabling. UI defaults to concept application, and busy jobs lock criteria fields.

This supersedes code 11's combined activity indicator. The analysis spinner runs only during reading/combining/saving; the lower question bar only during generation/review. Physical-phone live-model timing is not measured.


## a1 / code 13

Installed signed release code 12 on Android 16/API 36 Pixel 7 AVD (1080x2400, density 420, 4GB RAM, WHPX; software GPU). Imported a 12-page locally authored PDF through the Android document picker; UI showed full 12 pages and completion. Found WebView padding ignored under edge-to-edge. Code 13 wraps WebView in FrameLayout and applies system bars/display cutout/IME insets to layouts with pre-30 compatibility. Installed code 13 with adb -r: header is below system status bar and imported source count survives update. Shared safe-area helper also used in feature and note screens. Live ChatGPT analysis and generation await user login; do not count as passed.


## a1 / code 14

Live subscription connection showed GPT-6.1-Sol and 52 available models. Actual extraction preserved 8/12 pages after a page-link validation failure. Resume reused the checkpoints immediately at 66%; manual stop preserved them.

Fixed a misleading page-one declaration on PDF/evidence metadata and added an explicit per-request source/page contract; actual remaining extraction then completed 12/12 pages and entered synthesis. Strict validation remains and distinguishes unexpected pages, duplicate pages, and source ID mismatch. A late-page regression covers pages 8–12 and rejects a phantom page 1.

Persist AnalysisStatus failure details through finally/pause/reload, emit completed parallel-work counts immediately even if another request failed, and distinguish generation progress text. UI regression uses the native empty featurePractice:{} payload so first run remains on materials rather than empty study.

Live generation exposed a fabricated professor directive from a textbook. The draft was rejected before its scheduled review. Route draft validation defects to the existing second review, retain mandatory final validation, and fail immediately on explicit insufficient-evidence output. Generator seam tests verify repaired second pass success, invalid final refusal, and insufficient evidence without fabrication. Persist generationError inline and keep stage text separate from streamed-response activity. Current automated suites: 67 Java tests and 36 UI tests.

Final live check on Android 16 Pixel 7 emulator: GPT-6.1-Sol generated and reviewed five concept-application questions from the prepared 12-page PDF. The run took approximately 4 minutes 52 seconds, including the existing second review. No professor directives were invented in the final result. All 19 source quotations matched the corresponding PDF pages. Opened the original page 3 from an explanation and visually confirmed the correct page. Answered one question incorrectly and one correctly, marked one uncertain; range statistics showed the expected counts. Exported backup contained five questions, two answers, one correct, one incorrect, and one uncertain. Force-stop/relaunch preserved 2/5 solved, 50% accuracy, and one uncertain. The uncertain filter showed exactly that one question. Reset displayed an explicit confirmation; cancel preserved records. Restored the full question filter and left the emulator running.

Scope limits: email-based ChatGPT connection was verified; the Google sign-in path was not reverified after changing the emulator graphics backend. Physical-phone operation, hundreds-page real-model timing, and every customization/Clova workflow were not covered by this final live run. The fixture was an independently authored programming PDF, not a nursing textbook.

## a1 / code 15: remove redundant generated output

Keep the selected model and independent second review. The reviewer receives every source excerpt, full draft, and cached concept summary, but returns field edits rather than rewriting all unchanged content. Require exactly one unique valid question index and explicit true verdicts for answer/evidence/scope/options/wording for every question. Reject omitted checks, duplicate/out-of-range/fractional indices, failed verdicts, and unknown patch fields. Apply edits to a copy, then run the same final QuestionValidator/PastExpansion validators. No unreviewed partial dataset is saved.

Prepared concept generation reuses the original analysis notes verbatim as the cited concept summary, avoiding a new summary generation pass inside question drafting. Original and inferred past-exam modes retain their respective complete output and provenance contracts. No model, reasoning setting, per-option explanation, input evidence, or final verification is reduced. Store monotonic draft/review timings and response character counts in audit, without tokens or credentials.

Java tests: 76 passed. UI tests: 36 passed. Release lint: zero errors. Added regression checks for review completeness, patch isolation, preserved content, final answer/citation validation, prepared-summary reuse, original answer keys, and inferred past-exam coverage.

Live code 15 measurement on the same Android 16 emulator, same authored 12-page PDF, same prepared evidence and gpt-6.1-sol: draft 93,903 ms, independent review 22,714 ms, total model time 116,617 ms (approximately 1 minute 57 seconds). Previous code 14 observation was approximately 292 seconds, so this single before/after observation was approximately 60% shorter (2.5x throughput for this five-question run). Draft output 9,434 characters; review 2,029 characters. The review actually removed an unsupported textbook-based professor directive and corrected the overview. All five questions retained five option explanations (25 total); all 19 question citation occurrences and all 32 reused summary quotes matched the actual PDF pages. The previous study room retained both saved answers. No model or reasoning settings changed. These are single-run observations, not a guarantee for other documents or server conditions.

## a1 / code 16: published privacy policy

Published a static HTTPS privacy page at https://itsmemanright.github.io/studyforge-downloads/privacy.html . Anonymous fetch returned 200 and text/html; Korean policy title, approved contact email, and deletion instructions present. The policy distinguishes local encrypted storage from OpenAI/Naver transmission and explains logout, progress reset, source removal, full OS-level data removal, and exported-file retention accurately against code. It does not claim that source removal erases all originals or that store:false guarantees zero provider retention.

Added a globally reachable in-app policy button. The native external-link allowlist permits the exact policy URL, retaining existing official OpenAI destinations. Three additional tests reject disguised hosts, userinfo, unexpected ports, unrelated GitHub Pages paths, queries and unsafe schemes. Release Java 79 tests, UI 36 tests, zero failures; Release lint zero errors. AI generation/analysis behavior is unchanged; code 15 timing is a prior measurement, not rerun for this link-only update. App Store/Play review approval is not asserted.
