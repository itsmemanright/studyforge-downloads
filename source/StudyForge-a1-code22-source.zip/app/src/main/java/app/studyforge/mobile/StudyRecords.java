package app.studyforge.mobile;
import org.json.*;
final class StudyRecords {
    static JSONObject reset(JSONObject dataset) throws Exception {return Json.copy(dataset).put("answers",new JSONObject()).put("uncertain",new JSONObject()).put("completion",new JSONObject()).put("resetAt",System.currentTimeMillis());}
    /** Preserve completion, never copy the old selected index onto a new assessment. */
    static JSONObject revise(JSONObject dataset,String id,JSONObject replacement)throws Exception{
        JSONObject next=Json.copy(dataset),old=null;JSONArray rows=next.getJSONArray("questions");int index=-1;
        for(int i=0;i<rows.length();i++)if(id.equals(rows.getJSONObject(i).getString("id"))){old=rows.getJSONObject(i);index=i;break;}
        if(old==null)throw new Exception("개정할 문항을 찾을 수 없습니다.");
        JSONObject q=Json.copy(replacement);if(id.equals(q.getString("id")))throw new Exception("개정 문항에는 새 기록 식별자가 필요합니다.");
        q.put("originalId",old.optString("originalId",id)).put("previousId",id);
        JSONObject answers=next.optJSONObject("answers"),a=answers==null?null:answers.optJSONObject(id),completion=next.optJSONObject("completion");if(completion==null){completion=new JSONObject();next.put("completion",completion);}JSONObject carried=completion.optJSONObject(id);
        if(a!=null&&a.has("selected")){int wrong=carried==null?0:carried.optInt("priorWrong");JSONArray attempts=a.optJSONArray("attempts");if(attempts==null){if(a.getInt("selected")!=old.getInt("answer"))wrong++;}else for(int i=0;i<attempts.length();i++)if(attempts.getJSONObject(i).optInt("selected",-1)>=0&&attempts.getJSONObject(i).getInt("selected")!=old.getInt("answer"))wrong++;JSONObject uncertain=next.optJSONObject("uncertain");completion.put(q.getString("id"),Json.object("done",true,"correct",a.getInt("selected")==old.getInt("answer"),"uncertain",uncertain!=null&&uncertain.optBoolean(id),"carried",true,"priorWrong",wrong));}
        else if(carried!=null&&carried.optBoolean("done"))completion.put(q.getString("id"),Json.copy(carried));
        JSONArray history=next.optJSONArray("history");if(history==null){history=new JSONArray();next.put("history",history);}history.put(Json.object("question",Json.copy(old),"answer",a==null?JSONObject.NULL:Json.copy(a),"replacedAt",System.currentTimeMillis()));rows.put(index,q);return next;
    }
}
