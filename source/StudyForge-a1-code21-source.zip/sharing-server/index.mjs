import {createForgeSharing} from './forge-sharing.mjs';
const handler=createForgeSharing();
export default {async fetch(request,env){return (await handler(request,env))||new Response('Not found',{status:404});}};
