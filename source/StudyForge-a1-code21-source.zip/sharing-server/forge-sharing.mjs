// Capability access: readers receive a 256-bit invitation; publishing needs a
// separate owner secret. Neither ChatGPT credentials nor study answers enter R2.
export function createForgeSharing(){
 const enc=new TextEncoder(),prefix='studyforge-shared-v1/';
 const json=(value,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 const sha=async value=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(value)))].map(x=>x.toString(16).padStart(2,'0')).join('');
 const secret=()=>btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32)))).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
 const fail=(code,status=400)=>{const e=Error(code);e.status=status;throw e;};
 const text=(v,max,required=false)=>{if(typeof v!=='string'||v.length>max||required&&!v.trim())fail('invalid_bank');return v;};
 function keys(v,allowed){if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).some(k=>!allowed.includes(k)))fail('private_or_unknown_fields');}
 async function bank(input){
  keys(input,['title','subject','scope','overview','questions','summary','directives']);
  if(!Array.isArray(input.questions)||!input.questions.length||input.questions.length>1000)fail('question_limit');
  const seen=new Set(),qs=[];
  for(const q of input.questions){
   keys(q,['id','stem','topic','concept','options','answer','explanation','option_explanations','source_reference','inferred','provenance']);
   const id=text(q.id,180,true);if(seen.has(id))fail('duplicate_question');seen.add(id);
   if(!Array.isArray(q.options)||q.options.length!==5||new Set(q.options).size!==5||!Number.isInteger(q.answer)||q.answer<0||q.answer>4||!Array.isArray(q.option_explanations)||q.option_explanations.length!==5)fail('invalid_question');
   const next={id,stem:text(q.stem,10000,true),topic:text(q.topic||'',200),concept:text(q.concept||'',300),options:q.options.map(x=>text(x,4000,true)),answer:q.answer,explanation:text(q.explanation,16000,true),option_explanations:q.option_explanations.map(x=>text(x,8000,true)),source_reference:text(q.source_reference||'',1000)};
   next.assessment=await sha(JSON.stringify([id,next.stem,next.options,next.answer]));qs.push(next);
   if(q.inferred!==undefined&&typeof q.inferred!=='boolean')fail('invalid_question');
   if(q.inferred===true)next.inferred=true;
   if(q.provenance!==undefined)next.provenance=text(q.provenance,6000);
  }
  const list=(xs,allowed,limits)=>{if(xs===undefined)return [];if(!Array.isArray(xs)||xs.length>200)fail('invalid_bank');return xs.map(x=>{keys(x,allowed);return Object.fromEntries(allowed.map((k,i)=>[k,text(x[k]||'',limits[i])]))});};
  return{title:text(input.title,200,true),subject:text(input.subject||'',200),scope:text(input.scope||'',12000),overview:text(input.overview||'',12000),questions:qs,summary:list(input.summary,['title','text'],[300,16000]),directives:list(input.directives,['kind','title','text'],[30,300,16000])};
 }
 async function increment(bucket,key,max){
  for(let i=0;i<5;i++){
   const old=await bucket.get(key),value=old?await old.json():{count:0};if(value.count>=max)fail('sharing_limit',429);
   const written=await bucket.put(key,JSON.stringify({count:value.count+1}),{onlyIf:old?{etagMatches:old.etag}:new Headers({'If-None-Match':'*'})});if(written)return;
  }fail('try_again',429);
 }
 return async function(request,env){
  try{
   const url=new URL(request.url),origin=request.headers.get('Origin');
   if(origin&&origin!==url.origin)return json({error:'origin_not_allowed'},403);
   if(request.method!=='POST')return json({error:'method_not_allowed'},405);
   if(!env.BUCKET)return json({error:'sharing_unavailable'},503);
   if(!(request.headers.get('Content-Type')||'').startsWith('application/json'))return json({error:'json_required'},415);
   if(Number(request.headers.get('Content-Length')||0)>1_200_000)return json({error:'bank_too_large'},413);
   // Bound the stream before parsing, including chunked requests.
   const reader=request.body?.getReader();if(!reader)fail('invalid_request');let size=0,parts=[];
   while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>1_200_000){await reader.cancel();return json({error:'bank_too_large'},413);}parts.push(value);}
   const raw=new Uint8Array(size);let at=0;for(const p of parts){raw.set(p,at);at+=p.length;}let body;try{body=JSON.parse(new TextDecoder().decode(raw));}catch{fail('invalid_json');}
   const match=/^\/api\/shared-forges(?:\/([0-9a-f-]{36}))?$/.exec(url.pathname);if(!match)return json({error:'not_found'},404);
   const bucket=env.BUCKET,id=match[1];
   if(!id){
    keys(body,['action','bank']);if(body.action!=='create')fail('invalid_action');const content=await bank(body.bank);
    const date=new Date().toISOString().slice(0,10),ip=await sha(request.headers.get('CF-Connecting-IP')||'unknown');
    await increment(bucket,prefix+'quota/day/'+date,200);await increment(bucket,prefix+'quota/ip/'+date+'/'+ip,10);await increment(bucket,prefix+'quota/total',2000);
    const next=crypto.randomUUID(),read=secret(),owner=secret(),record={id:next,revision:1,createdAt:Date.now(),updatedAt:Date.now(),closed:false,readHash:await sha(read),ownerHash:await sha(owner),bank:content};
    await bucket.put(prefix+'forges/'+next,JSON.stringify(record),{onlyIf:new Headers({'If-None-Match':'*'})});
    return json({id:next,revision:1,readToken:read,ownerToken:owner,updatedAt:record.updatedAt,bank:content},201);
   }
   keys(body,['action','token','expectedRevision','bank']);const token=text(body.token,100,true);if(!/^[A-Za-z0-9_-]{43}$/.test(token))return json({error:'not_found'},404);
   const object=await bucket.get(prefix+'forges/'+id);if(!object)return json({error:'not_found'},404);const record=await object.json(),hashed=await sha(token),owner=hashed===record.ownerHash,readerAllowed=hashed===record.readHash;
   if(!owner&&!readerAllowed)return json({error:'not_found'},404);
   if(body.action==='read'){
    if(record.closed&&!owner)return json({error:'sharing_paused'},403);
    return json({id,revision:record.revision,updatedAt:record.updatedAt,closed:record.closed,bank:record.bank});
   }
   if(!owner)return json({error:'owner_required'},403);
   if(body.expectedRevision!==record.revision)return json({error:'revision_conflict',revision:record.revision},409);
   let newRead;
   if(body.action==='publish')record.bank=await bank(body.bank);
   else if(body.action==='pause')record.closed=true;
   else if(body.action==='resume'){record.closed=false;newRead=secret();record.readHash=await sha(newRead);}
   else fail('invalid_action');
   record.revision++;record.updatedAt=Date.now();
   const written=await bucket.put(prefix+'forges/'+id,JSON.stringify(record),{onlyIf:{etagMatches:object.etag}});if(!written)return json({error:'revision_conflict'},409);
   return json({id,revision:record.revision,updatedAt:record.updatedAt,closed:record.closed,...(newRead?{readToken:newRead}:{})});
  }catch(e){return json({error:e.status?e.message:'sharing_unavailable'},e.status||503);}
 };
}
