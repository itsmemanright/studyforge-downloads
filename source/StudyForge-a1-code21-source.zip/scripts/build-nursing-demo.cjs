const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict'),crypto=require('crypto');
const site=path.resolve(__dirname,'../../nursing-site'),ctx={window:{}};vm.runInNewContext(fs.readFileSync(path.join(site,'dist/study-catalog.js'),'utf8'),ctx);
const catalog=ctx.window.NURSING_STUDY_CATALOG,rooms=[],provenance=[];
for(const subject of ['maternity','pediatric','neuro','respiratory','mental']){
 const h=fs.readFileSync(path.join(site,'dist',subject+'.html'),'utf8'),Q=JSON.parse(h.match(/id="question-data"[^>]*>([\s\S]*?)<\/script>/)[1]);
 const family=catalog.families.find(f=>f.id===subject),groups=family.groups.filter(g=>g.path===subject+'.html'&&g.brand==='ai'&&!g.archived),ids=new Set(groups.flatMap(g=>g.rows.filter(q=>!q.excluded&&!q.low).map(q=>q.id)));
 const pools=new Map();
 for(const q of Q){const notes=q.option_explanations||q.explanations;if(!ids.has(String(q.id))||q.short_answer||q.type==='short'||q.options?.length!==5||!Number.isInteger(q.answer)||notes?.length!==5||new Set(notes).size<3||/PPT|슬라이드|교수|그림|사진|아래.*표|다음.*표/.test(q.question))continue;
  const chapter=String(q.chapter_number??q.chapter),pool=pools.get(chapter)||[];if(!pool.some(x=>(x.concept||x.goal||x.topic||x.id)===(q.concept||q.goal||q.topic||q.id)))pool.push(q);pools.set(chapter,pool);
 }
 const digest=q=>crypto.createHash('sha256').update('nursing-demo-20261019:'+String(q.id)).digest('hex');for(const pool of pools.values())pool.sort((a,b)=>digest(a).localeCompare(digest(b)));
 const chosen=[];for(let index=0;chosen.length<20;index++){let added=0;for(const pool of pools.values()){if(pool[index]){chosen.push(pool[index]);added++;if(chosen.length===20)break;}}assert(added,'Not enough distinct AI examples for '+subject);}
 const questions=chosen.map(q=>{
  const core=q.core_lesson||q.core||{},notes=q.option_explanations||q.explanations,parts=[q.explanation||notes[q.answer],...Object.entries(core).filter(([k,v])=>!Array.isArray(v)&&typeof v==='string').map(([k,v])=>v),...(q.friend_emphasis_notes||[]).map(n=>n.text)];
  const unique=[...new Set(parts.filter(Boolean))];
  provenance.push({subject,id:q.id,record_id:String(q.id),fingerprint:q.fingerprint||null,kind:'AI·교재 기반',scope:'current active source; no publisher, past-paper category or user records'});
  return{id:'example-'+subject+'-'+q.id,stem:q.question,options:q.options,answer:q.answer,explanation:unique.join('\n\n'),option_explanations:notes,topic:family.ranges?.find(r=>r.key===String(q.chapter_number??q.chapter))?.label||(/^\d+$/.test(String(q.chapter_number??q.chapter))?String(q.chapter_number??q.chapter)+'장':String(q.chapter_number??q.chapter)),concept:q.concept||q.goal||q.topic,source_reference:q.source||'',citations:[]};
 });
 rooms.push({id:'studyforge-demo-'+subject+'-20261019',demo:true,title:family.title+' · AI 예시 20문항',subject:family.title,overview:'간호학 문제은행의 AI·교재 기반 예시입니다. 체험은 AI 요청을 보내지 않으며 실제 학습 기록과 분리됩니다.',sources:[],questions,summary:[],directives:[],conflicts:[],answers:{},uncertain:{},history:[]});
}
assert.equal(rooms.length,5);assert.equal(rooms.reduce((n,d)=>n+d.questions.length,0),100);
const body=`(root=>{const examples=${JSON.stringify(rooms)};root.StudyNursingDemo={rooms:()=>JSON.parse(JSON.stringify(examples)),workspace:()=>{const rooms=JSON.parse(JSON.stringify(examples)),dataset=rooms.shift();return{sources:[],settings:{theme:'blue',pageSize:5,difficulty:'apply',custom:''},rooms,subject:dataset.subject,scope:'기말 AI 예시 20문항',priority:'textbook',generationMode:'concept',count:5,dataset};}};})(typeof window==='undefined'?globalThis:window);\n`;
fs.writeFileSync(path.join(__dirname,'../app/src/main/assets/demo-bank.js'),body);fs.writeFileSync(path.join(__dirname,'../demo-provenance.json'),JSON.stringify({date:'2026-10-19',site_version:154,items:provenance},null,2)+'\n');
console.log('Built 5 subjects × 20 active AI questions; no account, answer or source file data copied');
