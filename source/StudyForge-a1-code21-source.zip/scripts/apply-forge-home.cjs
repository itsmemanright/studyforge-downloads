const fs=require('fs');
let p='app/src/main/assets/app.js',x=fs.readFileSync(p,'utf8');
if(!x.includes('window.StudyForgeUI=')){
 const a=x.indexOf('function demoData()'),b=x.indexOf(' function toggleDemo()',a);if(a<0||b<0)throw Error('Demo function bounds missing');
 x=x.slice(0,a)+'function demoData(){return window.StudyNursingDemo.workspace();}\n'+x.slice(b);
 x=x.replace('예시 5문제를 풀어보세요.','간호 5과목의 AI 예시를 과목별20문항씩 풀어보세요.');
 x=x.replace("if(type==='ready'||type==='saveSettings'){return;}","if(type==='openRoom'&&demo){const next=w.rooms.find(d=>d.id===p.id);if(next){w.rooms=w.rooms.filter(d=>d.id!==p.id);w.rooms.push(w.dataset);w.dataset=next;w.subject=next.subject;page=0;$('filter').value='all';$('topic-filter').value='all';fields();renderStudy();}return;}if(type==='ready'||type==='saveSettings'){return;}");
 x=x.replace(" fields();renderAccount();renderSources();renderStudy();renderAnalysis();customizer.sync(w,account,busy,demo);features.sync(w,account,busy,demo);command('ready');", " window.StudyForgeUI={workspace:()=>w,isDemo:()=>demo,isBusy:()=>busy||importing,tab,notice,command,enterDemo:()=>{if(!demo)toggleDemo();},leaveDemo:()=>{if(demo)toggleDemo();},openRoom:id=>{page=0;$('filter').value='all';$('topic-filter').value='all';if(w.dataset?.id!==id)command('openRoom',{id});tab('study');}};\n fields();renderAccount();renderSources();renderStudy();renderAnalysis();customizer.sync(w,account,busy,demo);features.sync(w,account,busy,demo);command('ready');");
 fs.writeFileSync(p,x);
}
p='app/src/main/assets/index.html';x=fs.readFileSync(p,'utf8');
if(!x.includes('id="forge-home"')){
 x=x.replace('<span class="version">PROTOTYPE a1</span>','<button id="forge-home-button" class="secondary small">포지 선택</button><span class="version">a1</span>');
 const home='<section id="forge-home" class="tab-page" aria-label="포지 선택"><div class="section-top"><div><span class="eyebrow">STUDYFORGE</span><h1>오늘은 어디서 공부할까요?</h1></div></div><div id="forge-mode-buttons" class="forge-mode-buttons"><button id="personal-forge" class="primary">내 개인 포지</button><button id="shared-forge" class="secondary">친구와 공유 포지</button></div><section id="forge-personal-panel" class="card"><div class="section-top"><h2 id="forge-personal-title">내 개인 포지</h2><button id="forge-add-material" class="primary">＋ 자료 추가</button></div><p class="muted" id="forge-personal-description">교재·PPT·족보·녹취를 넣고 내 공부 공간을 만드세요.</p><div id="forge-personal-rooms" class="forge-cards"></div></section><section id="forge-shared-panel" class="card" hidden><h2>친구와 공유 포지</h2><p class="muted">문제·해설·시험 범위만 공유합니다. 원본 파일·ChatGPT 연결·각자의 답안과 오답은 공유하지 않습니다.</p><div class="forge-join"><label for="forge-invite">친구에게 받은 초대 코드</label><input id="forge-invite" autocomplete="off" spellcheck="false" maxlength="120" placeholder="SF1.…"><button id="forge-join" class="primary">공유 포지 참여</button></div><div class="forge-mode-buttons"><button id="forge-create" class="secondary">현재 학습실 공유하기</button><button id="forge-refresh" class="secondary">목록 새로고침</button></div><p id="forge-network-status" role="status"></p><div id="forge-shared-rooms" class="forge-cards"></div></section><section id="forge-demo-entry" class="card"><h2>간호학 문제은행 둘러보기</h2><p class="muted">모성·아동·신경·호흡감각·정신 · 과목별 AI20문항 · 로그인 없이 체험</p><button id="forge-demo" class="secondary">5과목 예시 열기</button></section></section>';
 x=x.replace('<section id="materials"',home+'<section id="materials"');
 x=x.replace('예시 5문제 · AI 요청 없음','간호 5과목 · 과목별20문항 · AI 요청 없음');
 x=x.replace('<script src="app.js"></script>','<script src="demo-bank.js"></script><script src="app.js"></script><script src="forges.js"></script>');
 fs.writeFileSync(p,x);
}
p='app/src/main/assets/quiz.js';x=fs.readFileSync(p,'utf8');x=x.replace("node('span',{},q.topic)","node('span',{hidden:!done},q.topic)");x=x.replace("(index+1)+'번 · '+q.topic,head","(index+1)+'번'+(state.answers[q.id]!==undefined?' · '+q.topic:''),head");fs.writeFileSync(p,x);
