package app.studyforge.mobile;
import org.junit.Test;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import static org.junit.Assert.*;
public class QuestionTutorTest {
 @Test public void conversationsSeparateAccountsRoomsAndRevisions()throws Exception{
  JSONObject q=Json.object("id","q1","stem","질문","answer",1),d=Json.object("id","room1");
  String key=QuestionTutor.key("a",d,q);assertNotEquals(key,QuestionTutor.key("b",d,q));assertNotEquals(key,QuestionTutor.key("a",Json.object("id","room2"),q));
  d.put("answers",Json.object("q1",0));assertEquals(key,QuestionTutor.key("a",d,q));q.put("answer",0);assertNotEquals(key,QuestionTutor.key("a",d,q));
 }
 @Test public void contextContainsOnlyCurrentQuestionAndProvidedReferences()throws Exception{
  JSONObject q=Json.object("id","q1","stem","약어 의미?"),d=Json.object("id","room","title","학습실","sources",Json.array(Json.object("secret","unrelated material")),"answers",Json.object("private","answer"));
  String c=QuestionTutor.context(d,q).toString();assertTrue(c.contains("약어"));assertFalse(c.contains("unrelated material"));assertFalse(c.contains("private"));assertEquals(0,QuestionTutor.context(d,q).getJSONArray("providedReferences").length());
 }
 @Test public void chatHasNativePerRequestConsentWithoutChangingLocalStudy(){assertTrue(AiConsent.required("chatSend"));assertTrue(AiConsent.disclosure("chatSend").contains("대화 이력"));assertFalse(AiConsent.required("chatOpen"));assertFalse(AiConsent.required("chatClear"));}
 @Test public void deltasAreLiveButFailureCannotBecomeACompletedAnswer()throws Exception{
  String stream="data: {\"type\":\"response.output_text.delta\",\"delta\":\"설명\"}\n\ndata: {\"type\":\"response.failed\",\"response\":{\"error\":{\"code\":\"response_failed\"}}}\n\n";
  StringBuilder live=new StringBuilder();try{Sse.read(new ByteArrayInputStream(stream.getBytes(StandardCharsets.UTF_8)),m->{},live::append);fail("Failed stream accepted");}catch(IOException expected){assertEquals("설명",live.toString());}
 }
}
