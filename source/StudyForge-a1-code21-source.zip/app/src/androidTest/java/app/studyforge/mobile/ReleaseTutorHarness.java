package app.studyforge.mobile;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import org.json.*;import java.lang.reflect.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
/** Optional live two-turn integration check using only developer-owned science content. */
final class ReleaseTutorHarness {
 final Instrumentation harness;StudyApp app;MainActivity screen;WebView web;JSONObject original;String owner,qaOwner;boolean isolated;
 ReleaseTutorHarness(Instrumentation i){harness=i;}
 void main(Runnable r){harness.runOnMainSync(r);}
 Object field(Object o,String name)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
 String js(String script)throws Exception{CountDownLatch latch=new CountDownLatch(1);AtomicReference<String> value=new AtomicReference<>();main(()->web.evaluateJavascript(script,v->{value.set(v);latch.countDown();}));if(!latch.await(10,TimeUnit.SECONDS))throw new Exception("WebView timeout");return value.get();}
 void awaitIdle()throws Exception{long until=SystemClock.uptimeMillis()+180000;while(app.busy&&SystemClock.uptimeMillis()<until)Thread.sleep(200);if(app.busy)throw new Exception("Live tutor did not finish within 180 seconds");}
 void approve()throws Exception{long until=SystemClock.uptimeMillis()+5000;AlertDialog d=null;while(SystemClock.uptimeMillis()<until){d=(AlertDialog)field(screen,"aiConsentDialog");if(d!=null)break;Thread.sleep(100);}if(d==null)throw new Exception("No native transmission consent");AlertDialog dialog=d;main(()->dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick());Thread.sleep(300);awaitIdle();}
 public void run(){Bundle result=new Bundle();long began=SystemClock.uptimeMillis();try{
  screen=(MainActivity)harness.startActivitySync(new Intent(harness.getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));app=(StudyApp)harness.getTargetContext().getApplicationContext();web=(WebView)field(screen,"web");
  if(app.busy)throw new Exception("Existing job kept untouched");if(!app.connection.connected())throw new Exception("Existing emulator ChatGPT login required");
  if(app.models.length()==0)app.reloadModels();long until=SystemClock.uptimeMillis()+45000;while(app.modelsLoading&&SystemClock.uptimeMillis()<until)Thread.sleep(200);if(app.models.length()==0)throw new Exception("No available account models");
  JSONObject q=Json.object("id","owned-science-q1","stem","캘빈 회로에서 ATP와 NADPH의 역할은?","topic","광합성","options",Json.array("탄소 고정에 에너지와 환원력을 제공","산소를 직접 운반","유전정보를 복제","세포벽을 분해","광자를 방출"),"answer",0,"explanation","ATP와 NADPH는 탄소 고정 과정에 에너지와 환원력을 제공합니다.","citations",new JSONArray());
  JSONObject dataset=Json.object("id","tutor-qa-room","title","개발자 작성 과학 예시","sources",new JSONArray(),"questions",Json.array(q),"answers",new JSONObject(),"uncertain",new JSONObject());
  synchronized(app){owner=app.profile;original=app.workspace;app.save();qaOwner="tutor_qa_"+java.util.UUID.randomUUID();app.profile=qaOwner;app.workspace=app.load(qaOwner);app.workspace.put("dataset",dataset).put("model",original.optString("model",app.models.getJSONObject(0).getString("slug")));isolated=true;app.state();}
  until=SystemClock.uptimeMillis()+20000;while(SystemClock.uptimeMillis()<until){if(js("typeof window.studyNativeReceive").contains("function"))break;Thread.sleep(100);}Thread.sleep(700);
  js("document.querySelector('[data-tab=study]').click();document.querySelector('.tutor-question-button').click();");Thread.sleep(300);
  js("document.querySelector('.tutor-dialog button[type=submit]').click();");approve();
  JSONObject first=app.vault.get(QuestionTutor.key(qaOwner,dataset,q));if(first.getJSONArray("messages").length()!=2)throw new Exception("First answer not persisted after completion");
  js("document.querySelector('.tutor-dialog textarea').value='ATP와 NADPH의 풀네임과 역할 차이를 쉽게 알려줘.';document.querySelector('.tutor-dialog button[type=submit]').click();");approve();
  JSONObject second=app.vault.get(QuestionTutor.key(qaOwner,dataset,q));if(second.getJSONArray("messages").length()!=4)throw new Exception("Follow-up history missing");
  if(dataset.getJSONObject("answers").length()!=0)throw new Exception("Tutor changed answer records");
  if(!js("document.querySelector('.tutor-history').innerText").contains("ATP"))throw new Exception("Tutor response not visible in same screen");
  android.graphics.Bitmap shot=harness.getUiAutomation().takeScreenshot();if(shot!=null){try(java.io.FileOutputStream out=new java.io.FileOutputStream(new java.io.File(harness.getTargetContext().getExternalFilesDir(null),"release19-tutor.png"))){shot.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}shot.recycle();}
  result.putString("result","passed");result.putString("stream","PASS: real account model completed two tutor turns through in-app chat UI and native consent, encrypted history has four messages, original answers unchanged. Developer-owned science fixture only. Elapsed ms "+(SystemClock.uptimeMillis()-began)+"\n");
 }catch(Throwable e){result.putString("result","failed");result.putString("stream","FAIL: "+e.getClass().getSimpleName()+": "+e.getMessage()+"\n");}
 finally{if(isolated&&app!=null)synchronized(app){app.cancel();app.profile=owner;app.workspace=original;app.state();}if(screen!=null)main(screen::finish);}
 harness.finish("passed".equals(result.getString("result"))?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
 }
}
