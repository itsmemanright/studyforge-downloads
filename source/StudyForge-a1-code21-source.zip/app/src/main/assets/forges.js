(()=>{'use strict';
 const api=window.StudyForgeUI;if(!api)return;
 const $=id=>document.getElementById(id),h=StudyQuiz.node;let mode='personal',shared=[];
 function datasets(){const w=api.workspace();return[w.dataset,...(w.rooms||[])].filter(Boolean);}
 function card(d,open){const s=StudyQuiz.stats(d),pct=s.total?Math.round(s.done/s.total*100):0;
  return h('button',{class:'forge-card',onclick:open},h('strong',{},d.subject||d.title),h('span',{class:'forge-room-title'},d.title),h('b',{class:'forge-percent'},pct+'%'),h('span',{},s.done+' / '+s.total+'문항'),h('progress',{max:Math.max(1,s.total),value:s.done,'aria-label':d.title+' 풀이 진행률'}),h('small',{},'오답 '+(s.done-s.right)+' · 헷갈림 '+s.uncertain));
 }
 function select(value){mode=value;render();api.tab('forge-home');}
 function action(type,payload={}){if(api.isDemo()){api.notice('체험을 끝낸 뒤 실제 포지를 공유할 수 있어요.');return;}if(api.isBusy()){api.notice('현재 작업을 마치거나 중단한 뒤 포지를 바꿔주세요.');return;}api.command(type,payload);}
 function render(){
  const demo=api.isDemo(),rows=datasets(),personal=rows.filter(d=>demo?d.demo:!d.sharedForge);
  $('forge-personal-panel').hidden=mode!=='personal';$('forge-shared-panel').hidden=mode!=='shared';
  $('personal-forge').className=mode==='personal'?'primary':'secondary';$('shared-forge').className=mode==='shared'?'primary':'secondary';
  $('forge-personal-title').textContent=demo?'간호학 AI 예시 · 과목별20문항':'내 개인 포지';
  $('forge-personal-description').textContent=demo?'과목을 골라 문제·해설·오답·범위별 통계를 체험하세요. 실제 자료·기록과 분리됩니다.':'교재·PPT·족보·녹취를 넣고 내 공부 공간을 만드세요.';
  $('forge-add-material').hidden=demo;$('forge-demo-entry').hidden=demo;
  const box=$('forge-personal-rooms');box.replaceChildren(...personal.map(d=>card(d,()=>api.openRoom(d.id))));
  if(!personal.length)box.append(h('p',{class:'empty'},'아직 만든 포지가 없어요. 자료 추가로 시작하세요.'));
  const list=$('forge-shared-rooms');list.replaceChildren();
  if(!demo)for(const f of shared){const d=rows.find(d=>d.sharedForge===f.id),entry=h('section',{class:'forge-shared-card'});
   entry.append(h('strong',{},f.title),h('small',{},(f.owner?'내가 만든 공유 포지':'친구와 함께')+' · '+(f.closed?'공유 중지':'버전 '+f.revision)+(f.syncedAt?' · '+new Date(f.syncedAt).toLocaleString('ko-KR'):'')));
   if(d)entry.append(card(d,()=>action('openSharedForge',{id:f.id})));
   const buttons=h('div',{class:'forge-card-actions'});buttons.append(h('button',{class:'secondary small',onclick:()=>action('refreshSharedForge',{id:f.id})},'최신 문제 받기'));
   if(f.owner){buttons.append(h('button',{class:'secondary small',disabled:!!f.closed,onclick:()=>action('shareForgeInvite',{id:f.id})},'초대 코드 공유'),h('button',{class:'secondary small',onclick:()=>action('publishSharedForge',{id:f.id,datasetId:api.workspace().dataset?.id||''})},'현재 학습실 게시'),h('button',{class:'secondary small',onclick:()=>action(f.closed?'resumeSharedForge':'pauseSharedForge',{id:f.id})},f.closed?'새 코드로 다시 공유':'공유 중지'));}
   entry.append(buttons);list.append(entry);
  }
  if(!shared.length||demo)list.append(h('p',{class:'empty'},demo?'체험 모드에서는 실제 공유를 요청하지 않습니다.':'초대 코드를 입력하거나, 내 학습실을 공유해 시작하세요.'));
  const usable=!demo&&!api.isBusy();$('forge-create').disabled=!usable||!api.workspace().dataset||!!api.workspace().dataset.sharedForge;
  $('forge-join').disabled=!usable;$('forge-refresh').disabled=!usable;
  $('forge-network-status').textContent=api.isBusy()?'현재 작업 중…':'';
 }
 $('personal-forge').onclick=()=>select('personal');$('shared-forge').onclick=()=>select('shared');
 $('forge-home-button').onclick=()=>{render();api.tab('forge-home');};
 $('forge-add-material').onclick=()=>{api.tab('materials');$('pick-file').click();};
 $('forge-demo').onclick=()=>{if(api.isBusy()){api.notice('진행 중인 작업을 완료하거나 중단한 뒤 체험해 주세요.');return;}api.enterDemo();mode='personal';render();api.tab('forge-home');};
 $('forge-join').onclick=()=>{const invite=$('forge-invite').value.trim();if(!/^SF1\.[0-9a-f-]{36}\.[A-Za-z0-9_-]{43}$/.test(invite)){api.notice('친구에게 받은 SF1.로 시작하는 초대 코드 전체를 입력하세요.');return;}action('joinSharedForge',{invite});$('forge-invite').value='';};
 $('forge-create').onclick=()=>action('createSharedForge',{datasetId:api.workspace().dataset?.id||''});
 $('forge-refresh').onclick=()=>action('refreshSharedForges');
 const receive=window.studyNativeReceive;
 window.studyNativeReceive=message=>{const e=typeof message==='string'?JSON.parse(message):message;receive(message);if(e.type==='state'){shared=Array.isArray(e.payload.sharedForges)?e.payload.sharedForges:[];render();}else if(e.type==='forgeJoined'){select('shared');}else if(e.type==='forgeOpened'){api.tab('study');render();}};
 // The regular demo entry still opens the selected subject immediately.
 const demoClick=$('demo').onclick,exitClick=$('demo-exit').onclick;
 $('demo').onclick=()=>{demoClick();render();};$('demo-exit').onclick=()=>{exitClick();mode='personal';render();api.tab('forge-home');};
 const initialTab=api.tab;api.tab=function(name){initialTab(name);};
 render();api.tab('forge-home');
})();
