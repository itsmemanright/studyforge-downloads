package app.studyforge.mobile;

import org.json.*;
import java.util.*;
import java.nio.charset.StandardCharsets;

/** The wire format is an allowlist, not a workspace backup. */
final class SharedStudy {
    static JSONObject bank(JSONObject dataset) throws Exception {
        if(dataset.optBoolean("demo"))throw new Exception("체험 자료는 실제 공유로 전송하지 않습니다.");
        JSONArray questions=dataset.getJSONArray("questions"),out=new JSONArray();
        if(questions.length()==0||questions.length()>1000)throw new Exception("공유할 학습실은 1~1,000문항이어야 합니다.");
        for(int i=0;i<questions.length();i++){
            JSONObject q=questions.getJSONObject(i),next=Json.object("id",q.optString("originalId",q.getString("id")),"stem",q.getString("stem"),"options",Json.arrayCopy(q.getJSONArray("options")),"answer",q.getInt("answer"),"explanation",q.getString("explanation"),"option_explanations",Json.arrayCopy(q.getJSONArray("option_explanations")),"topic",q.optString("topic"),"concept",q.optString("concept"),"source_reference",q.optString("source_reference"));
            if(q.optJSONObject("past")!=null){JSONObject p=q.getJSONObject("past");next.put("inferred",true).put("provenance","족보 단서 기반 추론·재구성 · 실제 기출 원문 확인 아님\n"+p.optString("method")+" · 확실도 "+p.optString("confidence")+"\n"+p.optString("confidence_reason")+"\n근거: "+(p.optJSONObject("basis")==null?"":p.getJSONObject("basis").optString("text"))+"\n없던 부분: "+p.optJSONArray("missing")+"\n추가·변형: "+p.optJSONArray("added")+"\n가정: "+p.optJSONArray("assumptions")+"\n대안: "+p.optJSONArray("alternatives")+"\n남아 있던 답: "+p.optString("source_answer"));}
            else if(q.optBoolean("inferred"))next.put("inferred",true).put("provenance",q.optString("provenance"));
            out.put(next);
        }
        JSONObject config=dataset.optJSONObject("studyConfig");
        JSONObject result=Json.object("title",dataset.getString("title"),"subject",dataset.optString("subject",config==null?"":config.optString("subject")),"scope",dataset.optString("scope",config==null?"":config.optString("scope")),"overview",dataset.optString("overview"),"questions",out,"summary",textRows(dataset.optJSONArray("summary"),false),"directives",textRows(dataset.optJSONArray("directives"),true));
        if(result.toString().getBytes(StandardCharsets.UTF_8).length>1_100_000)throw new Exception("공유할 문제·해설이 1.1MB를 넘었습니다. 더 작은 학습실로 나눠 주세요. 원본 파일은 공유하지 않습니다.");
        return result;
    }
    static JSONArray textRows(JSONArray source,boolean directive) throws Exception {
        JSONArray out=new JSONArray();if(source==null)return out;
        for(int i=0;i<source.length();i++){JSONObject s=source.getJSONObject(i),r=Json.object("title",s.optString("title"),"text",s.optString("text"));if(directive)r.put("kind",s.optString("kind"));out.put(r);}return out;
    }
    static JSONObject merge(JSONObject remote,JSONObject before) throws Exception {
        String forge=remote.getString("id");if(!forge.matches("[0-9a-f-]{36}"))throw new Exception("공유 포지 주소가 잘못되었습니다.");
        JSONObject bank=remote.getJSONObject("bank"),next=Json.object("id","shared-"+forge,"sharedForge",forge,"sharedRevision",remote.getInt("revision"),"title",bank.getString("title"),"subject",bank.optString("subject"),"scope",bank.optString("scope"),"overview",bank.optString("overview"),"sources",new JSONArray(),"summary",bank.optJSONArray("summary"),"directives",bank.optJSONArray("directives"),"conflicts",new JSONArray());
        JSONObject answers=before==null?new JSONObject():Json.copy(before.optJSONObject("answers")==null?new JSONObject():before.getJSONObject("answers"));
        JSONObject uncertain=before==null?new JSONObject():Json.copy(before.optJSONObject("uncertain")==null?new JSONObject():before.getJSONObject("uncertain"));
        JSONObject completion=before==null?new JSONObject():Json.copy(before.optJSONObject("completion")==null?new JSONObject():before.getJSONObject("completion"));
        JSONArray history=before==null||before.optJSONArray("history")==null?new JSONArray():Json.arrayCopy(before.getJSONArray("history"));
        Map<String,JSONObject> prior=new HashMap<>();if(before!=null){JSONArray qs=before.getJSONArray("questions");for(int i=0;i<qs.length();i++){JSONObject q=qs.getJSONObject(i);prior.put(q.optString("originalId",q.getString("id")),q);}}
        JSONArray questions=new JSONArray(),wire=bank.getJSONArray("questions");Set<String> ids=new HashSet<>();
        if(wire.length()==0||wire.length()>1000)throw new Exception("공유 문항 수가 지원 범위를 벗어났습니다.");
        for(int i=0;i<wire.length();i++){
            JSONObject q=Json.copy(wire.getJSONObject(i));String base=q.getString("id"),assessment=q.getString("assessment");
            if(!assessment.matches("[0-9a-f]{64}")||q.getJSONArray("options").length()!=5||q.getJSONArray("option_explanations").length()!=5||q.getInt("answer")<0||q.getInt("answer")>4)throw new Exception("공유 문항 구조를 확인할 수 없습니다.");
            String id="shared-q-"+assessment;if(!ids.add(id))throw new Exception("공유 자료에 중복 문항이 있습니다.");q.put("originalId",base).put("id",id).put("citations",new JSONArray());
            JSONObject old=prior.get(base);if(old!=null&&!id.equals(old.getString("id"))){String oldId=old.getString("id");q.put("previousId",oldId);JSONObject a=answers.optJSONObject(oldId),carried=completion.optJSONObject(oldId);
                if(a!=null&&a.has("selected")){int wrong=carried==null?0:carried.optInt("priorWrong");JSONArray attempts=a.optJSONArray("attempts");if(attempts==null){if(a.getInt("selected")!=old.getInt("answer"))wrong++;}else for(int j=0;j<attempts.length();j++)if(attempts.getJSONObject(j).optInt("selected",-1)>=0&&attempts.getJSONObject(j).getInt("selected")!=old.getInt("answer"))wrong++;completion.put(id,Json.object("done",true,"correct",a.getInt("selected")==old.getInt("answer"),"uncertain",uncertain.optBoolean(oldId),"carried",true,"priorWrong",wrong));}
                else if(carried!=null&&carried.optBoolean("done"))completion.put(id,Json.copy(carried));
                boolean exists=false;for(int j=0;j<history.length();j++)if(oldId.equals(history.getJSONObject(j).getJSONObject("question").optString("id")))exists=true;
                if(!exists)history.put(Json.object("question",Json.copy(old),"answer",a==null?JSONObject.NULL:Json.copy(a),"replacedAt",System.currentTimeMillis()));
            }else if(old!=null&&old.has("previousId"))q.put("previousId",old.getString("previousId"));
            questions.put(q);
        }
        for(JSONObject old:prior.values())if(!ids.contains(old.getString("id"))){boolean included=false;for(int j=0;j<questions.length();j++)if(old.optString("originalId",old.getString("id")).equals(questions.getJSONObject(j).optString("originalId")))included=true;if(!included){boolean exists=false;for(int j=0;j<history.length();j++)if(old.getString("id").equals(history.getJSONObject(j).getJSONObject("question").optString("id")))exists=true;if(!exists)history.put(Json.object("question",Json.copy(old),"answer",answers.has(old.getString("id"))?Json.copy(answers.getJSONObject(old.getString("id"))):JSONObject.NULL,"removedAt",System.currentTimeMillis()));}}
        next.put("questions",questions).put("answers",answers).put("uncertain",uncertain).put("completion",completion).put("history",history);
        return next;
    }
}
