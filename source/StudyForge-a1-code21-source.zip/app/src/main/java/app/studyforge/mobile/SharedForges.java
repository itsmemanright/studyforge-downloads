package app.studyforge.mobile;

import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;

/** Only sanitized question banks travel to the sharing server. Progress stays
 * in the existing encrypted per-account workspace. Capabilities never enter JS. */
final class SharedForges {
    static final String ENDPOINT="https://nursing-question-bank.sunminwoo0228.chatgpt.site/api/shared-forges";
    final StudyApp app;
    SharedForges(StudyApp app){this.app=app;}
    static String key(String owner){return "shared_forges_"+EncryptedBlocks.hash(owner).substring(0,32);}
    JSONObject access(String owner)throws Exception{JSONObject value=app.vault.get(key(owner));if(!value.has("forges"))value.put("forges",new JSONArray());return value;}
    JSONObject entry(JSONObject access,String id)throws Exception{JSONArray a=access.getJSONArray("forges");for(int i=0;i<a.length();i++)if(id.equals(a.getJSONObject(i).optString("id")))return a.getJSONObject(i);throw new Exception("이 계정에 저장된 공유 포지가 아닙니다.");}
    JSONArray publicList()throws Exception{JSONArray list=access(app.profile).getJSONArray("forges"),out=new JSONArray();for(int i=0;i<list.length();i++){JSONObject r=list.getJSONObject(i);out.put(Json.object("id",r.getString("id"),"title",r.optString("title"),"owner",!r.optString("ownerToken").isEmpty(),"revision",r.optInt("revision"),"syncedAt",r.optLong("syncedAt"),"closed",r.optBoolean("closed")));}return out;}
    JSONObject dataset(String id)throws Exception{JSONObject d=app.workspace.optJSONObject("dataset");if(d!=null&&id.equals(d.optString("id")))return d;JSONArray rooms=app.workspace.getJSONArray("rooms");for(int i=0;i<rooms.length();i++)if(id.equals(rooms.getJSONObject(i).optString("id")))return rooms.getJSONObject(i);throw new Exception("공유할 학습실이 바뀌었습니다.");}
    String confirmation(String type,JSONObject data)throws Exception{
        synchronized(app){if(app.busy)throw new Exception("현재 작업을 마치거나 중단한 뒤 공유하세요.");
            if(type.equals("createSharedForge")||type.equals("publishSharedForge")){JSONObject d=dataset(data.getString("datasetId"));SharedStudy.bank(d);return "‘"+d.getString("title")+"’ "+d.getJSONArray("questions").length()+"문항의 문제·보기·정답·해설·출처 표시·시험 범위를 스터디포지 공유 서버(Cloudflare)에 보관합니다.\n\n원본 PDF·사진·녹취 파일·답안·오답·개인 설정·ChatGPT 연결 정보는 보내지 않습니다. 초대 코드를 받은 사람은 공유 문제를 받을 수 있습니다. 실제 개인 학습 기록은 각자의 기기에 보관됩니다.";}
            if(type.equals("pauseSharedForge"))return "이 초대 코드로 최신 문제를 받는 것을 중지합니다. 친구 기기에 이미 받은 문제와 각자의 풀이 기록은 남습니다. 다시 공유하면 새 초대 코드를 발급합니다.";
            if(type.equals("resumeSharedForge"))return "새 초대 코드를 발급해 다시 공유합니다. 이전 코드는 더 이상 최신 문제를 받을 수 없습니다.";
            throw new Exception("지원하지 않는 공유 작업입니다.");
        }
    }
    void run(String type,JSONObject data)throws Exception{
        final String owner;final long job;final JSONObject request=Json.copy(data);
        synchronized(app){if(app.busy)throw new Exception("현재 작업을 마친 뒤 공유를 요청하세요.");owner=app.profile;app.busy=true;app.workPhase="sharing";job=++app.job;app.state();}
        app.worker.execute(()->{try{
            if(type.equals("createSharedForge"))create(owner,job,request.getString("datasetId"));
            else if(type.equals("joinSharedForge"))join(owner,job,request.getString("invite"));
            else if(type.equals("publishSharedForge"))publish(owner,job,request);
            else if(type.equals("pauseSharedForge")||type.equals("resumeSharedForge"))pause(owner,job,request.getString("id"),type.equals("pauseSharedForge"));
            else if(type.equals("openSharedForge")||type.equals("refreshSharedForge"))pull(owner,job,request.getString("id"),type.equals("openSharedForge"));
            else if(type.equals("refreshSharedForges")){JSONArray rows; synchronized(app){guard(owner,job);rows=Json.arrayCopy(access(owner).getJSONArray("forges"));}for(int i=0;i<rows.length();i++)try{pull(owner,job,rows.getJSONObject(i).getString("id"),false);}catch(Exception e){app.notice(e.getMessage());}}
            else throw new Exception("지원하지 않는 공유 작업입니다.");
        }catch(Exception e){synchronized(app){if(job==app.job&&owner.equals(app.profile))app.notice(e.getMessage());}}
        finally{synchronized(app){if(job==app.job&&owner.equals(app.profile)){app.busy=false;app.workPhase="";app.state();}}}});
    }
    void guard(String owner,long job)throws Exception{if(job!=app.job||!owner.equals(app.profile))throw new Exception("계정 또는 작업이 바뀌었습니다.");}
    void create(String owner,long job,String datasetId)throws Exception{
        JSONObject content,seed;synchronized(app){guard(owner,job);seed=Json.copy(dataset(datasetId));content=SharedStudy.bank(seed);}
        JSONObject response=request(null,Json.object("action","create","bank",content));
        synchronized(app){guard(owner,job);JSONObject a=access(owner),r=Json.object("id",response.getString("id"),"readToken",response.getString("readToken"),"ownerToken",response.getString("ownerToken"));updateMetadata(r,response);a.getJSONArray("forges").put(r);app.vault.put(key(owner),a);install(response,true,seed);app.emit("forgeJoined",response.getString("id"));app.notice("공유 포지를 만들었어요. ‘초대 코드 공유’로 친구에게 전달하세요.");}
    }
    void join(String owner,long job,String invite)throws Exception{
        if(!invite.matches("SF1\\.[0-9a-f-]{36}\\.[A-Za-z0-9_-]{43}"))throw new Exception("초대 코드 전체를 다시 확인하세요.");String[] bits=invite.split("\\.");JSONObject response=request(bits[1],Json.object("action","read","token",bits[2]));
        synchronized(app){guard(owner,job);JSONObject a=access(owner),r;try{r=entry(a,bits[1]);}catch(Exception e){r=Json.object("id",bits[1]);a.getJSONArray("forges").put(r);}r.put("readToken",bits[2]);updateMetadata(r,response);app.vault.put(key(owner),a);install(response,true);app.emit("forgeJoined",bits[1]);app.notice("공유 문제를 받았어요. 풀이·오답은 이 계정의 개인 기록으로 저장됩니다.");}
    }
    void pull(String owner,long job,String id,boolean open)throws Exception{
        JSONObject e;synchronized(app){guard(owner,job);e=Json.copy(entry(access(owner),id));if(open)try{openCached(id);}catch(Exception ignored){}}
        JSONObject response;
        try{response=request(id,Json.object("action","read","token",e.optString("ownerToken").isEmpty()?e.getString("readToken"):e.getString("ownerToken")));}
        catch(Exception error){if(open)app.notice("최신 문제를 받지 못했어요. 이미 받은 문제가 있으면 계속 풀 수 있습니다. "+error.getMessage());else throw error;return;}
        synchronized(app){guard(owner,job);JSONObject a=access(owner),r=entry(a,id);updateMetadata(r,response);app.vault.put(key(owner),a);install(response,open);if(open)app.emit("forgeOpened",id);else app.notice("공유 문제를 확인했어요. 내 풀이 기록은 보존했습니다.");}
    }
    void publish(String owner,long job,JSONObject input)throws Exception{
        JSONObject r,content;synchronized(app){guard(owner,job);r=Json.copy(entry(access(owner),input.getString("id")));if(r.optString("ownerToken").isEmpty())throw new Exception("공유 포지를 만든 사람만 게시할 수 있습니다.");content=SharedStudy.bank(dataset(input.getString("datasetId")));}
        JSONObject response=request(r.getString("id"),Json.object("action","publish","token",r.getString("ownerToken"),"expectedRevision",r.getInt("revision"),"bank",content));
        synchronized(app){guard(owner,job);JSONObject a=access(owner),e=entry(a,r.getString("id"));updateMetadata(e,response);e.put("title",content.getString("title"));app.vault.put(key(owner),a);app.notice("새 문제·해설·범위를 게시했어요. 친구는 ‘최신 문제 받기’로 반영할 수 있습니다.");}
        pull(owner,job,r.getString("id"),false);
    }
    void pause(String owner,long job,String id,boolean paused)throws Exception{
        JSONObject e;synchronized(app){guard(owner,job);e=Json.copy(entry(access(owner),id));if(e.optString("ownerToken").isEmpty())throw new Exception("공유를 만든 사람만 이 설정을 바꿀 수 있습니다.");}
        JSONObject response=request(id,Json.object("action",paused?"pause":"resume","token",e.getString("ownerToken"),"expectedRevision",e.getInt("revision")));
        synchronized(app){guard(owner,job);JSONObject a=access(owner),r=entry(a,id);updateMetadata(r,response);if(response.has("readToken"))r.put("readToken",response.getString("readToken"));app.vault.put(key(owner),a);app.notice(paused?"공유를 중지했어요. 받은 문제와 개인 기록은 지우지 않았습니다.":"다시 공유할 수 있어요. 새 초대 코드를 친구에게 전달하세요.");}
    }
    void updateMetadata(JSONObject e,JSONObject response)throws Exception{e.put("revision",response.getInt("revision")).put("closed",response.optBoolean("closed")).put("syncedAt",System.currentTimeMillis());if(response.optJSONObject("bank")!=null)e.put("title",response.getJSONObject("bank").getString("title"));}
    void install(JSONObject remote,boolean open)throws Exception{install(remote,open,null);}
    void install(JSONObject remote,boolean open,JSONObject seed)throws Exception{
        String id="shared-"+remote.getString("id");JSONObject previous=seed;try{previous=dataset(id);}catch(Exception ignored){}
        JSONObject next=SharedStudy.merge(remote,previous),current=app.workspace.optJSONObject("dataset");JSONArray rooms=app.workspace.getJSONArray("rooms"),rest=new JSONArray();
        for(int i=0;i<rooms.length();i++)if(!id.equals(rooms.getJSONObject(i).optString("id")))rest.put(rooms.get(i));
        if(open||current!=null&&id.equals(current.optString("id"))){if(current!=null&&!id.equals(current.optString("id")))rest.put(current);app.workspace.put("dataset",next);}else rest.put(next);
        app.workspace.put("rooms",rest);app.save();app.state();
    }
    void openCached(String id)throws Exception{
        String target="shared-"+id;JSONObject current=app.workspace.optJSONObject("dataset");
        if(current==null||!target.equals(current.optString("id"))){JSONObject found=dataset(target);JSONArray old=app.workspace.getJSONArray("rooms"),next=new JSONArray();for(int i=0;i<old.length();i++)if(!target.equals(old.getJSONObject(i).optString("id")))next.put(old.get(i));if(current!=null)next.put(current);app.workspace.put("rooms",next).put("dataset",found);app.save();}
        app.state();app.emit("forgeOpened",id);
    }
    static void copyProfile(SecureVault vault,String from,String to)throws Exception{
        JSONObject a=vault.get(key(from)),b=vault.get(key(to));JSONArray source=a.optJSONArray("forges"),target=b.optJSONArray("forges");if(source==null)return;if(target==null){target=new JSONArray();b.put("forges",target);}for(int i=0;i<source.length();i++){JSONObject r=source.getJSONObject(i);boolean seen=false;for(int j=0;j<target.length();j++)if(r.optString("id").equals(target.getJSONObject(j).optString("id")))seen=true;if(!seen)target.put(Json.copy(r));}vault.put(key(to),b);
    }
    String invite(String id)throws Exception{synchronized(app){JSONObject e=entry(access(app.profile),id);if(e.optString("ownerToken").isEmpty()||e.optBoolean("closed"))throw new Exception("공유를 만든 사람이 활성 초대 코드를 전달할 수 있습니다.");return "SF1."+id+"."+e.getString("readToken");}}
    static JSONObject request(String id,JSONObject body)throws Exception{
        if(id!=null&&!id.matches("[0-9a-f-]{36}"))throw new Exception("공유 포지 주소를 확인하세요.");
        HttpsURLConnection c=(HttpsURLConnection)new URL(ENDPOINT+(id==null?"":"/"+id)).openConnection();
        c.setInstanceFollowRedirects(false);c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");
        try{byte[] payload=body.toString().getBytes(StandardCharsets.UTF_8);if(payload.length>1_200_000)throw new Exception("공유 용량이 큽니다. 더 작은 학습실로 나눠 주세요.");c.setFixedLengthStreamingMode(payload.length);try(OutputStream out=c.getOutputStream()){out.write(payload);}int status=c.getResponseCode();String raw=Api.read(status<400?c.getInputStream():c.getErrorStream(),2_000_000);JSONObject result;try{result=new JSONObject(raw);}catch(Exception e){throw new Exception("공유 서버에 연결하지 못했습니다. 잠시 뒤 다시 시도하세요.");}if(status>=200&&status<300)return result;String code=result.optString("error");throw new Exception(switch(code){case "not_found"->"초대 코드가 틀렸거나 새 코드로 바뀌었습니다.";case "sharing_paused"->"공유자가 현재 공유를 중지했습니다.";case "revision_conflict"->"다른 곳에서 새 버전을 게시했습니다. 최신 문제를 받은 뒤 다시 게시하세요.";case "sharing_limit","try_again"->"현재 공유 요청 한도에 도달했습니다. 나중에 다시 시도하세요.";case "bank_too_large","question_limit"->"공유할 학습실을 더 작게 나눠 주세요.";default->"공유 요청을 완료하지 못했습니다. 문제·해설 구조와 연결을 확인하세요.";});}finally{c.disconnect();}
    }
}
